// test-lazy-root.mjs - C4IX's root archive read where it is kept
// (docs/c4ix-design.md, "The root archive, read where it is kept").
//
// Where there is a drive 1, persist inflates c4ix-root.tgz onto it as
// 1:c4ix-base.tar and makes each file in it a lazy file on its span of
// the tar ("1:c4ix-base.tar@OFF+LEN", devices.js diskOpen): nothing of
// the tree is in RAM after boot. A file read is read from the drive; a
// small one is kept while memory allows (the cache, vfs.c) and dropped
// when memory is short, a changed one stays. Checked here:
//
//   - the first boot unpacks onto the drive and reads from there; the
//     second reads the copy it kept; either way /proc/cache has the
//     tree's files still on the host, and the heap after boot is
//     megabytes smaller than a boot without a drive (the tree in RAM)
//   - the files are the archive's, byte for byte (crc32 in the machine
//     against the tar here), small, big and a program; a program in the
//     tree runs; and b4ke finds /build exactly as up to date as the boot
//     without a drive does, so the modification order is the tar's
//   - eviction: files read are kept; with the heap taken past 7/8 from
//     outside, the next allocation drops them all, and read again they
//     are the same; a file changed since boot is not dropped, and keeps
//     its change
//   - a drive 1 that takes nothing (no sink) gets the RAM unpack, as no
//     drive does; booted from the kept copy, RAM files are under
//     RAM_FILES_KB, not the tree's megabytes
//   - the desktop boots in a small machine: from the kept copy and on a
//     first boot, MMU on and off, each in at most its limit (SMALLEST)
//   - a desktop boot whose root archive is damaged has no desktop, and
//     says the archive could not be read
//   - a desktop boot that does not fit has no desktop, and says it ran out of memory
//
//   node libjs/tests/test-lazy-root.mjs

import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { gunzipSync, crc32 } from 'node:zlib';
import { createMachine, boot } from '../boot.js';
import { STOP } from '../c4m.js';
import { GuiDevice } from '../gui-device.js';
import { typeBytes } from '../keys.js';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('../../src/c4bb/images/', import.meta.url));
const DISK = join(ROOT, 'disk');
let fail = 0;
const check = (cond, what, extra = '') => {
  console.log(`test-lazy-root: ${what} ${cond ? 'OK' : 'FAILED'}${!cond && extra ? '\n  ' + String(extra).slice(-1500) : ''}`);
  if (!cond) fail = 1;
  return cond;
};
if (!existsSync(join(DISK, 'c4ix-root.tgz')) || !existsSync(join(DISK, 'index.json'))) {
  console.log('test-lazy-root: SKIPPED, no c4ix-root.tgz (make c4bb-images builds it)');
  process.exit(0);
}

// the archive's files, as the machine should read them
const tar = gunzipSync(readFileSync(join(DISK, 'c4ix-root.tgz')));
const want = new Map();
for (let pos = 0; pos + 512 <= tar.length && tar[pos]; ) {
  const h = tar.subarray(pos, pos + 512), str = (a, n) => h.subarray(a, a + n).toString('latin1').replace(/\0.*$/s, '');
  const name = (h[345] ? str(345, 155) + '/' : '') + str(0, 100), size = parseInt(str(124, 12).trim() || '0', 8);
  if (h[156] === 48 || h[156] === 0) want.set('/' + name.replace(/^\.\//, ''), tar.subarray(pos + 512, pos + 512 + size));
  pos += 512 + Math.ceil(size / 512) * 512;
}
const hex = b => (crc32(b) >>> 0).toString(16).padStart(8, '0');
const small = [...want].filter(([n, b]) => b.length > 0 && b.length <= 65536 && n.startsWith('/usr/src/c4ix/')).slice(0, 24).map(([n]) => n);
const big = [...want].filter(([n, b]) => b.length > 65536).map(([n]) => n).slice(0, 3);
const prog = '/build/bin/c4ix-echo.c4r';
const files = [...small, ...big, '/usr/BUILD.B4K'];
// one a line: the shell's lines are not long enough for them all
const crcs = names => names.map(n => `crc32 ${n}`).join('\n');
const crcLines = (text, names) => names.map(n => (text.match(new RegExp(`^[0-9a-f]{8} \\d+ ${n.replace(/[.+]/g, '\\$&')}$`, 'm')) || [''])[0]);
const wanted = names => names.map(n => `${hex(want.get(n))} ${want.get(n).length} ${n}`);

class LazyDisk extends Map {
  constructor() { super(); this.sizes = new Map(JSON.parse(readFileSync(join(DISK, 'index.json'), 'utf8'))); }
  has(n) { return super.has(n) || this.sizes.has(n); }
  get(n) {
    if (super.has(n)) return super.get(n);
    if (!this.sizes.has(n)) return undefined;
    const b = new Uint8Array(readFileSync(join(DISK, n)));
    super.set(n, b);
    return b;
  }
}
const disk = new LazyDisk();

// C4IX on the console, drive 1 kept in STORE (none: no drive 1;
// SINKLESS: a drive 1 that takes nothing written, devices.js's read-only),
// drive 0 DRIVE0 (the boot disk)
function machine({ mb = 64, store = null, mmu = true, desktop = false, sinkless = false, drive0 = disk } = {}) {
  const out = [];
  const drives = [{ files: drive0, writable: false, sink: null }];
  if (store) drives.push({ files: new Map(store), writable: true, sink: (n, b) => store.set(n, b), remove: n => store.delete(n) });
  else if (sinkless) drives.push({ files: new Map(), writable: true, sink: null, remove: () => {} });
  const gui = desktop ? new GuiDevice({ w: 640, h: 480 }) : null;
  const vm = createMachine({ arenaMb: mb, mmu, gui, drives, onByte: b => out.push(b) });
  boot(vm, new Uint8Array(readFileSync(join(ROOT, 'c4ix32.c4r'))), desktop ? ['c4ix32.c4r', '--desktop'] : ['c4ix32.c4r']);
  let halted = false;
  const text = (from = 0) => Buffer.from(out.slice(from)).toString('latin1');
  const run = () => { if (vm.run(2e6) === STOP.HALT) halted = true; if (gui) gui.drain(); };
  const until = (cond, budget = 4000) => { for (let i = 0; i < budget && !halted; i++) { if (cond()) return true; run(); } return cond(); };
  let seq = 0;
  // CMDS typed at the prompt; what they printed
  const sh = (cmds, budget = 4000) => {
    const n0 = out.length, mark = `@@${++seq}@@`;
    typeBytes(vm, new TextEncoder().encode(`${cmds}\necho ${mark}\n`));
    until(() => text(n0).includes(mark + '\n'), budget);
    return text(n0);
  };
  return { vm, sh, text, until, halted: () => halted };
}
const cache = t => { const m = /lazy (\d+) (\d+)\ncached (\d+) (\d+)\ndropped (\d+)/.exec(t); return m ? m.slice(1).map(Number) : null; };
const kb = n => Math.round(n / 1024);
// /proc/meminfo's "name value" lines (vfs.c), the last of each
const meminfo = t => Object.fromEntries([...t.matchAll(/^(files|nfiles|heap|used|free|cached|lazy) (\d+)$/gm)].map(m => [m[1], +m[2]]));
// Booted from the copy kept on drive 1, the RAM files are only what boot
// writes itself (68 KB in 2, 2026-11-12); the tree in RAM is 24 MB
const RAM_FILES_KB = 1024;
// The smallest machines the desktop is up in, [MB, MMU, from the kept
// copy]. Measured 2026-11-13, headless and in the page alike: from the
// kept copy 8 MB with the MMU and 7 without (78889dc: 9 and 7); the
// first boot, which inflates the archive onto the drive, 8 MB
// with the MMU and 7 without (78889dc: 14 and 12; before arc_readfile
// read the archive into one buffer of its size, 10 and 21; before persist
// inflated it as it read it, arc_gunzip_file, rather than reading all
// 4.3 MB of it first, 8 and 10). With the MMU
// the first boot needed 10 until the archive's one 4 MB read into
// persist's buffer, whose first pages swap had put out again by the time
// of the read, wrote them (arena.js dmaSwapped): it stopped at the first
// and said it had read it all, and persist found zeros ("not a tar
// archive"). A boot that needs more than these has put the tree, or
// something new, back in RAM.
const SMALLEST = [[8, true, true], [6, false, true], [8, true, false], [6, false, false]];

// ---- no drive: the tree unpacked into RAM, as before ----
const ram = machine();
const ramOut = ram.sh('wait 4\n' + crcs(files) + '\nb4ke -n -C /usr');
const ramUsed = ram.vm.heap.used;
check(crcLines(ramOut, files).join('\n') === wanted(files).join('\n'), 'without a drive the tree is unpacked into RAM, the archive\'s bytes',
  crcLines(ramOut, files).join('\n'));
const ramB4ke = ramOut.split('\n').filter(l => /^b4ke|RUN|would/.test(l)).join('\n');

// ---- a drive 1 that takes nothing: the tree unpacked into RAM too ----
{
  const ro = machine({ sinkless: true });
  const t = ro.sh('wait 4\n' + crcs(files) + '\ncat /proc/meminfo');
  const m = meminfo(t);
  check(!/read from there/.test(t) && crcLines(t, files).join('\n') === wanted(files).join('\n') && m.files > 12 << 10,
    `a drive 1 that takes nothing gets the tree unpacked into RAM, as no drive does (${m.files} KB in ${m.nfiles} RAM files)`,
    t.split('\n').filter(l => /persist|vfsload/.test(l)).join(' | '));
}

// ---- the first boot with a drive: inflated onto it, read from there ----
const store = new Map();
const first = machine({ store });
let t = first.sh('wait 4\ncat /proc/cache');
check(/persist: c4ix-root\.tgz: \d+ files, unpacked onto drive 1 and read from there/.test(t) &&
  store.has('c4ix-base.tar') && store.get('c4ix-base.tar').length === tar.length,
  'the first boot inflates the archive onto drive 1 and reads it from there', t.split('\n').filter(l => /persist|vfsload/.test(l)).join(' | '));
let c = cache(t);
check(c && c[0] >= want.size && c[2] < 16, `its ${want.size} files are on the host after boot (/proc/cache: ${c && c.join(' ')})`, t);
const firstUsed = first.vm.heap.used;
check(ramUsed - firstUsed > 12 << 20, `the heap after boot: ${kb(firstUsed)} KB, ${kb(ramUsed - firstUsed)} KB less than with the tree in RAM`,
  `${kb(ramUsed)} KB without a drive`);

// ---- the second: the copy kept ----
const kept = machine({ store });
t = kept.sh('wait 4\ncat /proc/meminfo\n' + crcs(files) + `\n${prog} lazy-run-ok\nb4ke -n -C /usr\ncat /proc/cache`);
check(/persist: c4ix-root\.tgz: \d+ files from the copy kept on drive 1, read from there/.test(t),
  'the next boot reads the copy kept on drive 1', t.split('\n').filter(l => /persist/.test(l)).join(' | '));
const km = meminfo(t);
check(km.files < RAM_FILES_KB, `and after it ${km.files} KB is in ${km.nfiles} RAM files, under ${RAM_FILES_KB} KB: the tree's ${kb(tar.length)} KB is not in RAM`,
  JSON.stringify(km));
check(crcLines(t, files).join('\n') === wanted(files).join('\n'), `${small.length} small files, ${big.length} big ones and /usr/BUILD.B4K are the archive's, byte for byte`,
  crcLines(t, files).join('\n'));
check(/^lazy-run-ok$/m.test(t), 'a program in the tree runs from the drive');
const keptB4ke = t.split('\n').filter(l => /^b4ke|RUN|would/.test(l)).join('\n');
check(keptB4ke === ramB4ke && ramB4ke.length > 0, 'b4ke finds /build as up to date as with the tree in RAM', `drive:\n${keptB4ke}\nRAM:\n${ramB4ke}`);
c = cache(t);
check(c && c[2] >= small.length && c[3] > 0, `the small files read are kept (/proc/cache: ${c && c.join(' ')})`);

// ---- eviction: memory short, the cache gives way; a changed file stays ----
t = kept.sh(`echo changed > /usr/BUILD.B4K\n${crcs(['/usr/BUILD.B4K'])}`);
const changed = Buffer.from('changed\n');
const changedLine = `${hex(changed)} ${changed.length} /usr/BUILD.B4K`;
check(crcLines(t, ['/usr/BUILD.B4K'])[0] === changedLine, 'a file of the tree written to has its change', crcLines(t, ['/usr/BUILD.B4K'])[0]);
const h = kept.vm.heap, size = h.end - h.base;
const hog = h.alloc(Math.floor(size * 0.92) - h.used);
t = kept.sh('cat /proc/cache');
c = cache(t);
check(hog && c && c[2] === 0 && c[4] >= small.length, `with 92% of the heap taken, the next allocation drops every cached file (/proc/cache: ${c && c.join(' ')})`, t);
h.free(hog);
t = kept.sh(crcs(files));
const again = wanted(files).map(l => l.endsWith(' /usr/BUILD.B4K') ? changedLine : l);
check(crcLines(t, files).join('\n') === again.join('\n'), 'read again from the drive they are the same, and the changed file kept its change',
  crcLines(t, files).join('\n'));
t = kept.sh('persist status');
check(/^  \/usr\/BUILD\.B4K$/m.test(t), 'and persist status has it as a change to save', t);

// ---- without the MMU, the same ----
const nommu = machine({ store, mmu: false });
t = nommu.sh('wait 4\n' + crcs(files));
check(/read from there/.test(t) && crcLines(t, files).join('\n') === wanted(files).join('\n'), 'without the MMU too', crcLines(t, files).join('\n'));

// ---- what a save keeps is the drive's again, and the next boot's ----
// A file written is RAM's. Saved, a big one is read from its span of the
// snapshot and its RAM freed (a small one is kept, a cache); the next
// boot reads them from there too and untars nothing into RAM; and saves
// after it, each into the snapshot the last did not use, leave them the
// bytes they were, the boot after included.
{
  const pstore = new Map();
  // the archive's biggest file: big enough to see in the heap
  const [src, bytes] = [...want].reduce((x, y) => y[1].length > x[1].length ? y : x);
  const mine = [['/usr/big.bin', bytes], ['/usr/small.txt', Buffer.from('small\n')]];
  const mineLines = () => mine.map(([n, b]) => `${hex(b)} ${b.length} ${n}`);
  const used = m => (m.sh('cat /proc/cache'), m.vm.heap.used);
  const p1 = machine({ store: pstore });
  p1.sh(`wait 4\ncat ${src} > /usr/big.bin\necho small > /usr/small.txt`);
  const written = used(p1);
  t = p1.sh('persist save\n' + crcs(mine.map(([n]) => n)));
  const saved = used(p1);
  check(/persist: \d+ changes and \d+ deletions kept/.test(t) && crcLines(t, mine.map(([n]) => n)).join('\n') === mineLines().join('\n'),
    'a save: the files are their bytes, read from the snapshot', t.slice(-600));
  check(written - saved > bytes.length * 0.9, `and the big one's RAM is freed (${kb(written - saved)} KB of the heap back, it is ${kb(bytes.length)} KB)`);
  t = p1.sh('echo again > /usr/again.txt\npersist save\n' + crcs(mine.map(([n]) => n)));
  check(pstore.has('c4ix-persist.tar') && pstore.has('c4ix-persist-b.tar') && Buffer.from(pstore.get('c4ix-persist.cur')).toString() === 'b' &&
    crcLines(t, mine.map(([n]) => n)).join('\n') === mineLines().join('\n'),
    'a second save goes into the other snapshot, and the files are still their bytes', t.slice(-600));
  // two at once, as the desktop's persist -d and a sync typed can be: they
  // take turns (persist.c's lock), and neither writes into the other
  t = p1.sh('echo both > /usr/both.txt\npersist save &\npersist save &\nwait\n' + crcs(mine.map(([n]) => n)) + '\ncat /usr/both.txt');
  check((t.match(/persist: \d+ changes and \d+ deletions kept/g) || []).length === 2 && !/failed|another save/.test(t) &&
    crcLines(t, mine.map(([n]) => n)).join('\n') === mineLines().join('\n') && /^both$/m.test(t),
    'two saves at once take turns, and the files are still their bytes', t.slice(-800));

  // the same drive with nothing saved, for the heap a boot takes
  const bare = machine({ store: new Map([...pstore].filter(([n]) => !/persist/.test(n))) });
  bare.sh('wait 4');
  const bareUsed = used(bare);
  const p2 = machine({ store: pstore });
  t = p2.sh('wait 4\n' + crcs(mine.map(([n]) => n)));
  const p2Used = used(p2);
  check(/persist: \d+ files kept from the last session/.test(t) && crcLines(t, mine.map(([n]) => n)).join('\n') === mineLines().join('\n'),
    'the next boot has them, their bytes', t.slice(-600));
  check(p2Used - bareUsed < bytes.length / 2, `read from the snapshot, not untarred into RAM (the heap ${kb(p2Used - bareUsed)} KB more than with nothing saved)`);
  t = p2.sh('persist save\n' + crcs(mine.map(([n]) => n)));
  check(Buffer.from(pstore.get('c4ix-persist.cur')).toString() === 'a' && crcLines(t, mine.map(([n]) => n)).join('\n') === mineLines().join('\n'),
    'saved again, into the snapshot its files were not read from, they are their bytes', t.slice(-600));
  const p3 = machine({ store: pstore });
  t = p3.sh('wait 4\n' + crcs(mine.map(([n]) => n)) + '\ncat /usr/again.txt\ncat /usr/both.txt');
  check(crcLines(t, mine.map(([n]) => n)).join('\n') === mineLines().join('\n') && /^again$/m.test(t) && /^both$/m.test(t),
    'and so does the boot after', t.slice(-600));
}

// ---- the smallest machines the desktop is up in ----
{
  const base = new Map([...store].filter(([n]) => /^c4ix-base\./.test(n)));
  for (const [mb, mmu, fromKept] of SMALLEST) {
    const m = machine({ mb, mmu, store: fromKept ? new Map(base) : new Map(), desktop: true });
    m.until(() => m.halted() || /desktop: running on the display|out of memory/.test(m.text()), 4000);
    const t = m.text();
    check(/desktop: running on the display/.test(t) && /read from there/.test(t) && !/out of memory|Trap type|store to/i.test(t),
      `the desktop is up in ${mb} MB${mmu ? '' : ' without the MMU'}, ${fromKept ? 'from the copy kept on drive 1' : 'on a first boot'}`,
      t.split('\n').filter(l => /persist|memory|desktop|Trap/i.test(l)).join(' | '));
  }
}

// ---- a desktop boot that does not fit has no desktop, and says why ----
// (with the MMU, 5 MB: with swap -- memory on demand, paged against its
// own -- the system fits in 7 now, where it did not in 12 before,
// docs/c4ix-mmu.md 11. In 5 either the root archive cannot be unpacked,
// and the boot stops there, or it can, by a few KB of the heap's layout,
// and the desktop cannot load: the shell says so, and there is still a
// console. Without the MMU nothing makes room: in 5 MB the desktop
// cannot load. In 6 it could not until the loader stopped reading each
// program's code through a kernel buffer of the whole file)
for (const [mb, mmu] of [[5, true], [5, false]]) {
  const tiny = machine({ mb, mmu, store: new Map(), desktop: true });
  tiny.until(() => tiny.halted() || /desktop: running on the display|sh: out of memory starting desktop/.test(tiny.text()), 3000);
  t = tiny.text();
  check((tiny.halted() || /sh: out of memory starting desktop/.test(t)) && /out of memory/.test(t) && !/desktop: running/.test(t) && !/store to|Trap type/i.test(t),
    `a desktop boot in ${mb} MB${mmu ? '' : ' without the MMU'} has no desktop, saying it ran out of memory`, t.slice(-700));
}

// ---- a desktop boot whose root archive is damaged: no desktop, and why ----
// (persist's exit status 4; vfsload passes it on and init stops there,
// docs/c4ix-design.md: a desktop on no tree looks like one, and then
// every program on it fails)
{
  const bad = new LazyDisk();
  const tgz = Uint8Array.from(bad.get('c4ix-root.tgz'));
  for (let k = 0; k < 64; k++) tgz[(tgz.length >> 1) + k] ^= 0x5a;
  bad.set('c4ix-root.tgz', tgz);
  const dstore = new Map();
  const dm = machine({ store: dstore, desktop: true, drive0: bad });
  dm.until(() => dm.halted() || /desktop: running on the display|boot stops here/.test(dm.text()), 4000);
  t = dm.text();
  check(/persist: c4ix-root[.]tgz: /.test(t) && /root archive could not be read/.test(t) && !/desktop: running/.test(t) &&
    !/out of memory|store to|Trap type/i.test(t) && !(dstore.get('c4ix-base.id') || []).length,
    'a desktop boot whose root archive is damaged has no desktop, saying the archive could not be read',
    t.split('\n').filter(l => /persist|vfsload|c4ix:|desktop/.test(l)).join(' | '));
}

process.exit(fail);
