// worker.js - the machine, in a Web Worker.
//
// The page never touches the interpreter. It sends messages (boot, keys,
// signals, display events) and gets messages back (console bytes,
// status, draw commands). postMessage only, so this works from any
// static server; nothing here needs cross-origin isolation.
//
// Page -> worker
//   boot    { image: ArrayBuffer, argv, disk: [[name, ArrayBuffer]], arenaMb, mhz, unpaced, gui, snd, shared }
//           snd: true fits the sound card (snd-device.js); midi: true gives
//           it a General MIDI synth on its MIDI port (page.js, opts.music)
//           persist: { files: [[name, Uint8Array]] } fits a writable drive 1, kept by the page
//           uploads: [[name, Uint8Array]] laid over drive 0: the disk's file of that name is hidden
//                    (and C4IX lists them in /home: uploads.js); with uploadsHome (C4DOS),
//                    over drive 1, B:, instead (uploads.js HomeFiles), which is there for them
//                    even where nothing is kept
//           cpus, quantum: that many processors, simulated (smp.js)
//           parallel: ... each on a worker of its own (par.js), when the page is
//           cross-origin isolated; simulated otherwise
//           shared: { ring, fb } SharedArrayBuffers from shared.js, when the page is isolated
//   key     { key, ctrlKey, altKey, metaKey }     a keydown on the terminal
//   input   { bytes: Uint8Array }                 typed programmatically
//   paste   { text }                              pasted: typed a line at a time, as the guest reads (keys.js Paste)
//   signal  { sig }                               2 = Ctrl-C
//   eof     {}                                    Ctrl-D
//   gui     { kind, ... }                         a display event (gui-device.js)
//   pause / resume / reset
//   reset-files                                   drive 1 emptied, then reset; answered with files-reset
//   cache   { files: [[name, hash, bytes]] }       what the page keeps of the lazy disk (lazy.js)
//   peek    { id, addr, len }                     read guest memory
//   poke    { id, addr, bytes }                   write guest memory
// Worker -> page
//   out     { bytes }         console output, and the echo of what was typed
//   kbd     { raw }           a program opened or closed /dev/tty
//   display { frames }        draw commands (gui-device.js); not used on the shared path
//   snd     { events, now }   the sound card's events, and its clock when sent (snd-device.js)
//   persist { name, bytes }   a file the machine closed on drive 1, for the page to keep;
//                             bytes null: one it took off drive 1, for the page to forget
//   files-reset {}            drive 1 is empty and the machine is booting again
//   download { name, bytes }  a file the machine hands the person (C4IX's download:
//                             devices.js "download:NAME"), for the page to save
//   cache   { name, hash, bytes }  a lazy disk's file with a hash, read from the server: for the page to keep
//   status  { ... }           about four times a second; cpuIps: each CPU's
//                             inst/s over the last second or so (cpuIps, below);
//                             osAccel: the OS accelerators' switch (accel.js ACC_OS)
//   exit    { status, cycles }
//   reply   { id, ... }       for peek and poke
//   error   { message }

import { createMachine, boot } from './boot.js';
import { STOP } from './c4m.js';
import { keyDown, typeBytes, Paste } from './keys.js';
import { GuiDevice } from './gui-device.js';
import { SoundDevice, EVT } from './snd-device.js';
import { RingWriter, FbProducer } from './shared.js';
import { layUploads, HomeFiles } from './uploads.js';
import { LazyFiles } from './lazy.js';
import { loadAccel, accelManifest, osAccelOn } from './accel.js';

// A disk read on demand (lazy.js). The page sends an index and a base
// URL; the first get() of a name fetches that one file with a
// synchronous XHR (allowed in a worker, and the machine's OPEN is
// synchronous anyway) and keeps it.
function fetchSync(base, name) {
  const x = new XMLHttpRequest();
  x.open('GET', base + name.split('/').map(encodeURIComponent).join('/'), false);
  x.responseType = 'arraybuffer';
  x.send();
  return x.status === 200 ? new Uint8Array(x.response) : null;
}
// The files the page's cache had (a 'cache' message, after boot), and
// those fetched since that it keeps: [[name, hash, bytes]]. Kept here for
// the worker's life, so a reset reads none of them again.
let cacheFiles = [];

// Drive 1, when the page keeps one: made once, so a reset boots with what
// the machine last wrote there, not what the page had at load.
let persistDrive = null;
let vm = null, bootMsg = null, gui = null, snd = null, ring = null, ringStalls = 0, handoffMs = 0;
// One producer per shared framebuffer for the Worker's whole life: which
// slot is ours is state the page's side depends on, and a reset must not
// forget it.
let fbProducer = null, fbSab = null;
let paused = false, halted = false, parked = false;
let out = [];
let tRun = 0, lostMs = 0, parkedAt = 0;
let busyMs = 0, lastStatus = { t: 0, cycle: 0, busy: 0 };
let lastRaw = 0, state = 'idle';

// Scheduling. A slice runs, then yields so messages can arrive. The
// zero-delay yield is a MessageChannel, because setTimeout(0) is clamped
// to 4 ms once nested; a generation number makes every earlier wake-up
// a no-op, so there is only ever one tick queued.
let gen = 0;
const chan = new MessageChannel();
chan.port1.onmessage = e => { if (e.data === gen) tick(); };
function schedule(ms) {
  const g = ++gen;
  if (ms <= 0) chan.port2.postMessage(g);
  else setTimeout(() => { if (g === gen) tick(); }, ms);
}

function flush() {
  if (!out.length) return;
  const bytes = new Uint8Array(out);
  out = [];
  postMessage({ type: 'out', bytes }, [bytes.buffer]);
}

function flushDisplay() {
  if (!gui) return;
  gui.onPresent = flushDisplay;
  const frames = gui.drain();
  if (frames) {
    if (ring) {
      // Shared path: into the ring, as much as fits; the rest waits for
      // the page to catch up (a background tab draws nothing).
      const n = ring.write(frames);
      if (n < frames.length) { gui.putBack(frames.subarray(n)); ringStalls++; }
    } else postMessage({ type: 'display', frames }, [frames.buffer]);
  }
  const req = gui.takeSizeRequest();
  if (req) postMessage({ type: 'gui', w: req.w, h: req.h });
}

// The sound card's events, for the page's AudioWorklet. Its clock is
// this one, real time: the audio plays in real time whether or not the
// machine keeps up, so the stream is kept ahead of the clock the audio
// goes by (snd-device.js).
function flushSound() {
  if (!snd) return;
  const events = snd.drain();
  if (!events) return;
  const transfer = [];
  for (const e of events) if (e[5] instanceof Uint8Array) transfer.push(e[5].buffer);
  postMessage({ type: 'snd', events, now: performance.now() * 1000 }, transfer);
}

// the parallel engine's host side (par.js), when there is one
let par = null, parStuck = 0;     // since when every CPU has been parked, or 0
// While CPU 0 is not running -- paced, parked, or waiting for a key --
// the other CPUs' requests are answered as soon as they ask
// An IPI for CPU 0 ends its nap, as a message for the machine does.
function watchPar() {
  if (!par || halted) return;
  if (state === 'sleeping' && par.ipiFor0()) wake();
  par.watch(watchPar);
}

function start(msg) {
  if (par) { par.shutdown(); par = null; }
  parStuck = 0;
  bootMsg = msg;
  ring = msg.gui && msg.shared ? new RingWriter(msg.shared.ring) : null;
  if (ring && fbSab !== msg.shared.fb) { fbSab = msg.shared.fb; fbProducer = new FbProducer(fbSab); }
  // the page's: BLIT8's pixels in its order, and frames it would only cover dropped
  gui = msg.gui ? new GuiDevice({ ...msg.gui, fbShared: ring ? fbProducer : null, abgr: true, dropCovered: true }) : null;
  snd = msg.snd ? new SoundDevice({ now: () => performance.now() * 1000, midi: !!msg.midi }) : null;
  // The page's mixer outlives a reset, and with it whatever the old
  // machine left playing: the new one starts quiet, whatever it boots
  if (snd) snd.emit([EVT.RESET, snd.now()]);
  ringStalls = 0;
  // Files arrive as Uint8Arrays or bare ArrayBuffers; the disk
  // controller wants bytes it can index.
  // A lazy disk's files with a hash go to the page to keep, as they are read.
  const files = msg.lazy ? new LazyFiles(msg.lazy.index, name => fetchSync(msg.lazy.base, name), (name, hash, bytes) => {
    cacheFiles.push([name, hash, bytes]);
    postMessage({ type: 'cache', name, hash, bytes: bytes.slice() });
  }) : new Map((msg.disk || []).map(([n, b]) => [n, b instanceof Uint8Array ? b : new Uint8Array(b)]));
  if (msg.lazy) files.fill(cacheFiles);
  // the uploads over them, and in C4DOS's and C4IX's listings (uploads.js);
  // under C4DOS on B: instead (below)
  const home = !!msg.uploadsHome && !!(msg.uploads && msg.uploads.length);
  layUploads(files, msg.uploads, !!msg.uploadsHome);
  const drives = [{ files, writable: false, sink: null }];
  const keep = (name, bytes) => { const b = bytes.slice(); postMessage({ type: 'persist', name, bytes: b }, [b.buffer]); };
  if (msg.persist) {
    if (!persistDrive) persistDrive = {
      files: new Map(msg.persist.files), writable: true,
      sink: keep,
      // a file the machine took off the drive (DISK_UNLINK): gone from the page's store too
      remove: name => postMessage({ type: 'persist', name, bytes: null }),
    };
    drives.push(persistDrive);
  }
  // C4DOS's uploads on B: (drive 1): over what the page keeps there, which
  // gets only what is the person's own (HomeFiles.kept); or, where nothing
  // is kept (?persist=0), over a B: for this boot alone
  if (home) {
    const base = msg.persist ? persistDrive : { files: new Map() };
    const over = new HomeFiles(base.files, msg.uploads, msg.persist ? keep : null);
    drives[1] = {
      files: over, writable: true,
      sink: msg.persist ? (name, bytes) => keep(name, over.kept(name, bytes)) : () => {},
      remove: msg.persist ? persistDrive.remove : null,
    };
  }
  vm = createMachine({
    unpackLog: m => console.log(m),
    arenaMb: msg.arenaMb || 64, drives, mhz: msg.mhz || 20, gui, snd, fpu: msg.fpu, accel: msg.accel, osAccel: msg.osAccel,
    cpus: msg.cpus | 0, quantum: msg.quantum | 0, mmu: !!msg.mmu,
    parallel: !!msg.parallel, spawn: url => new Worker(url, { type: 'module' }),
    onByte: b => { out.push(b); if (out.length >= 4096) flush(); },
    onDownload: (name, bytes) => { const b = bytes.slice(); postMessage({ type: 'download', name, bytes: b }, [b.buffer]); },
  });
  boot(vm, new Uint8Array(msg.image), msg.argv || ['image.c4r'], { mbox: msg.mbox | 0 });
  par = vm.smp && vm.smp.parallel ? vm.smp : null;
  watchPar();
  paused = false; halted = false; parked = false;
  paste.clear();
  tRun = performance.now(); lostMs = 0; busyMs = 0;
  lastStatus = { t: tRun, cycle: 0, busy: 0 };
  ipsLast = null;
  lastRaw = 0;
  state = 'running';
  schedule(0);
}

// A paste waiting to go in (keys.js Paste): its next line, when the guest
// has read the last one and asked for more. True if one went in.
const paste = new Paste();
function feedPaste() {
  const e = vm && paste.pending ? paste.feed(vm) : null;
  if (e) echo(e);
  return !!e;
}

function tick() {
  if (!vm || paused || halted) return;
  if (parWaiting()) return;
  feedPaste();
  const now = performance.now();
  if (parked) { lostMs += now - parkedAt; parked = false; }
  const dev = vm.dev;
  // Paced, a slice is 4 simulated milliseconds, so the machine is never
  // more than a frame ahead of the clock. And on a host slower than the MHz
  // asked for, TIME crawls through a slice and then jumps by what it lost
  // (realtime, below): over 16 ms at 400 MHz, 50 ms of crawl and a jump of 34,
  // which a game paced by TIME sees as uneven frames. Unpaced, it is simply big.
  const slice = bootMsg.unpaced ? 5e6 : dev.cyclesPerMs * 4;
  const t = performance.now();
  let r;
  try {
    r = vm.run(slice);
  } catch (e) {
    flush();
    halted = true; state = 'halted';
    postMessage({ type: 'error', message: `libjs: ${e.message}` });
    return;
  }
  busyMs += performance.now() - t;
  flush();
  if (par && !dev.halted && r !== STOP.HALT) {
    par.service();
    if (r === STOP.PARK || r === STOP.CPUHALT || vm.cpuState !== 'run') {
      flushDisplay(); flushSound();
      // every CPU parked or halted for three seconds, none asking: nothing can wake them
      const now = performance.now();
      parStuck = par.allParked() ? parStuck || now : 0;
      if (parStuck && now - parStuck >= 3000) { par.deadlock(); flush(); }
      else if (vm.cpuState === 'halt' && par.othersDone()) { dev.halted = true; dev.status = vm.cpuStatus; }
      if (dev.halted) {
        halted = true; state = 'halted';
        postStatus(true);
        postMessage({ type: 'exit', status: dev.status, cycles: vm.cycle });
        par.shutdown();
        return;
      }
      // CPU 0 waits for its word, an IPI or another CPU, a few ms at a
      // time, so the page's messages are taken between
      state = 'parked';
      par.parkSync(8);
      schedule(0);
      return;
    }
    parStuck = 0;
  }
  const td = performance.now();
  flushDisplay();
  flushSound();
  handoffMs += performance.now() - td;
  if (dev.rawKbd !== lastRaw) { lastRaw = dev.rawKbd; postMessage({ type: 'kbd', raw: lastRaw > 0 }); }

  if (r === STOP.HALT) {
    if (par) par.shutdown();
    halted = true; state = 'halted';
    postStatus(true);
    postMessage({ type: 'exit', status: dev.status, cycles: vm.cycle });
    return;
  }
  if (r === STOP.INPUT) {
    // a paste's next line, which this read was waiting for
    if (feedPaste()) { schedule(0); return; }
    // Waiting for a key with no timer armed: nothing happens until a
    // message arrives. With the PIT armed, come back when it is due.
    parked = true; parkedAt = performance.now(); state = 'blocked';
    if (dev.pitMs) schedule(Math.max(1, dev.pitNext - dev.hostNow()));
    return;
  }
  state = r === STOP.SLEEP ? 'sleeping' : 'running';
  if (!bootMsg.unpaced) {
    // Pace to the machine's own clock: guests time themselves against
    // TIME (cycles / MHz plus time slept), so a simulated second should
    // take a real one.
    const ahead = dev.simMs() - (performance.now() - tRun - lostMs);
    if (ahead > 2 && par && par.othersRunning()) {
      parWaitUntil = performance.now() + Math.min(ahead, 100);
      schedule(0);
      return;
    }
    if (ahead > 2) { schedule(Math.min(ahead, 100)); return; }
    // Behind. With realtime (the page's default), the machine's clock is
    // the wall's: TIME moves on by what the CPU could not get done, so a
    // host slower than the MHz asked for gives the guest fewer cycles a
    // second, not a slower second -- a game drops frames rather than
    // playing in slow motion, and the sound card's stream (its time is
    // TIME's) keeps up. Without it, the machine's own second stretches.
    if (bootMsg.realtime && ahead < -20) dev.sleepMs += -ahead;
    else if (ahead < -1000) lostMs += -ahead - 1000;   // hopelessly behind: stop trying to catch up
  } else if (par && r === STOP.SLEEP && par.othersRunning()) {
    // unpaced, CPU 0 still naps while the others work, until an IPI
    parWaitUntil = performance.now() + Math.min(dev.napMs, 100);
  }
  schedule(0);
}

// CPU 0 waits while the other CPUs work -- paced to the clock, or napping
// unpaced -- blocked in Atomics.wait, a few ms at a time, so their
// requests are answered at once (par.js sleepSync); between turns the
// worker takes its messages. An IPI ends the wait, and a nap with it.
let parWaitUntil = 0;
function parWaiting() {
  if (!parWaitUntil) return false;
  const left = parWaitUntil - performance.now();
  if (left <= 0 || !par || !par.othersRunning()) { parWaitUntil = 0; return false; }
  if (par.ipiFor0()) { parWaitUntil = 0; wake(); return true; }
  par.sleepSync(left, 8);
  schedule(0);
  return true;
}

// A message for the machine (a key, a pointer move) while it waits for
// the clock. Paced, the machine's time must not get ahead of the real
// one, however many messages come:
// - asleep (it napped, USLP), the nap is cut short at the real time --
//   the guest has not read the clock since it napped, so to it the nap
//   simply ended early, as an interrupt would end it -- and it runs now;
// - ahead after work, it does not run early: the wait already armed
//   ends within a slice, and the message is taken then.
// Running at once and keeping the whole nap gave the guest a nap's worth
// of time for every pointer move: top, the raycasters and System Monitor
// all sped up while the mouse moved (5x, measured).
function wake() {
  if (!vm || paused || halted) return;
  if (!bootMsg.unpaced) {
    const dev = vm.dev;
    const ahead = dev.simMs() - (performance.now() - tRun - lostMs);
    if (ahead > 0 && state === 'running') return;     // a wait is armed
    if (ahead > 0 && state === 'sleeping') {
      const cut = Math.min(Math.floor(ahead), dev.napMs);
      dev.sleepMs -= cut;
      dev.napMs -= cut;
    }
  }
  parWaitUntil = 0;
  schedule(0);
}

function postStatus(force) {
  if (!vm) return;
  const now = performance.now();
  const dt = now - lastStatus.t;
  if (!force && dt < 200) return;
  const ran = vm.cycle - vm.skipped;
  postMessage({
    type: 'status',
    state: paused ? 'paused' : state,
    cycle: vm.cycle,
    ips: dt > 0 ? Math.round((ran - lastStatus.cycle) / dt * 1000) : 0,
    cpuIps: cpuIps(now),
    busy: dt > 0 ? Math.min(1, (busyMs - lastStatus.busy) / dt) : 0,
    heapUsed: vm.heap.used,
    missedTraps: vm.missedTraps,
    simMs: vm.dev.simMs(),
    raw: vm.dev.rawKbd > 0,
    runMs: Math.round(busyMs),
    disk: lazyStats(),
    gui: gui ? { ...gui.stats(), shared: !!ring, ringStalls, handoffMs: Math.round(handoffMs) } : null,
    snd: snd ? snd.stats() : null,
    osAccel: osAccelOn(),           // the OS accelerators' switch, which the guest may turn (accel.js)
  });
  lastStatus = { t: now, cycle: ran, busy: busyMs };
}
setInterval(() => postStatus(false), 250);

// Each CPU's instructions per second, over the last second or so, for the
// page's status line: one figure per CPU, CPU 0 first. The counts are the
// ones each engine keeps anyway (smp.js's and par.js's cpuCycles; ap.js
// publishes its own after every slice), read here as a status goes out,
// so the instructions themselves pay nothing. They come in their low 32
// bits, and are added up here as they move.
let ipsLast = null, ipsTotal = null, ipsWin = [];
function cpuIps(now) {
  const smp = vm.smp && vm.smp.cpuCycles ? vm.smp : null, n = smp ? smp.n : 1;
  if (!ipsLast || ipsLast.length !== n) { ipsLast = new Array(n).fill(0); ipsTotal = new Array(n).fill(0); ipsWin = []; }
  for (let k = 0; k < n; k++) {
    const c = smp ? smp.cpuCycles(k) : (vm.cycle - vm.skipped) | 0;
    let d = (c - ipsLast[k]) | 0;
    if (d < 0) d = c >>> 0;             // that CPU started again, from 0 (CPUS)
    ipsLast[k] = c;
    ipsTotal[k] += d;
  }
  // the oldest sample kept is the newest one at least a second old
  ipsWin.push({ t: now, c: ipsTotal.slice() });
  while (ipsWin.length > 2 && now - ipsWin[1].t >= 1000) ipsWin.shift();
  const a = ipsWin[0], dt = now - a.t;
  return ipsTotal.map((c, k) => dt > 0 ? Math.round((c - a.c[k]) / dt * 1000) : 0);
}

function lazyStats() {
  const f = vm && vm.dev.drives[0] && vm.dev.drives[0].files;
  // and the files made from their packages (unpack.js), each with how long it took
  const made = f && f.unpacked ? f.unpacked.map(u => ({ name: u.name, ms: u.ms })) : [];
  return f instanceof LazyFiles ? { lazy: true, files: f.sizes.size, fetched: f.fetched, bytes: f.fetchedBytes, cached: f.cached, made } : { lazy: false, made };
}

function echo(bytes) { for (const b of bytes) out.push(b); flush(); }

const onMessage = e => {
  const m = e.data;
  try {
    switch (m.type) {
      case 'boot': start(m); break;
      case 'reset': if (bootMsg) start(bootMsg); break;
      // what the page's cache had for the lazy disk
      case 'cache': {
        cacheFiles = cacheFiles.concat(m.files);
        const f = vm && vm.dev.drives[0] && vm.dev.drives[0].files;
        if (f instanceof LazyFiles) f.fill(m.files);
        break;
      }
      case 'reset-files':
        if (persistDrive) persistDrive.files = new Map();
        if (bootMsg) start(bootMsg);
        postMessage({ type: 'files-reset' });
        break;
      case 'key':
        // Ctrl-C ends a paste too: what had not gone in yet is dropped
        if (m.ctrlKey && (m.key === 'c' || m.key === 'C')) paste.clear();
        if (vm) { echo(keyDown(vm, m).echo); wake(); }
        break;
      case 'input': if (vm) { echo(typeBytes(vm, m.bytes)); wake(); } break;
      case 'paste': if (vm && paste.add(m.text)) { feedPaste(); wake(); } break;
      case 'signal': paste.clear(); if (vm) { vm.pendingSignal = m.sig | 0 || 2; wake(); } break;
      case 'eof': if (vm) { vm.dev.rxEof = true; wake(); } break;
      case 'gui': if (gui) { gui.event(m); wake(); } break;
      case 'pause':
        if (vm && !paused) { paused = true; parkedAt = performance.now(); parked = true; postStatus(true); }
        break;
      case 'resume':
        if (vm && paused) { paused = false; postStatus(true); wake(); }
        break;
      case 'peek': {
        const a = m.addr >>> 0, n = Math.max(0, m.len | 0);
        const bytes = vm ? vm.u8.slice(a, a + n) : new Uint8Array(0);
        postMessage({ type: 'reply', id: m.id, bytes }, [bytes.buffer]);
        break;
      }
      case 'poke':
        if (vm) vm.u8.set(m.bytes, m.addr >>> 0);
        postMessage({ type: 'reply', id: m.id, ok: !!vm });
        break;
    }
  } catch (err) {
    postMessage({ type: 'error', message: `libjs: ${err.message}` });
  }
};

// The games' accelerators (accel.js) are loaded before the machine starts,
// the build's list: what the page says meanwhile waits for them, in order
const accelReady = accelManifest().then(loadAccel).catch(e => console.error('libjs: accelerators:', e));
const waiting = [];
let accelLoaded = false;
accelReady.then(() => { accelLoaded = true; for (const e of waiting.splice(0)) onMessage(e); });
self.onmessage = e => { if (accelLoaded) onMessage(e); else waiting.push(e); };
