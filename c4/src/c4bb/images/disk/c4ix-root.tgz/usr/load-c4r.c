//
// Executable loader: .c4r format
//
// Invocation: c4m load-c4r.c -- hello.c4r
//
// See asm-c4r.c for layout
//

#include "c4.h"
#include "c4m.h"

// Configuration
enum {
	// How far to search for an ENT instruction when printing stacktraces,
	// in words.
	ST_FUNC_SEARCH_MAX = 0xFFFF
};


// C4INFO state - must match that in c4m.c
enum {
	C4I_NONE = 0x0,  // No C4 info
	C4I_C4   = 0x1,  // Ultimately running under C4
	C4I_C4M  = 0x2,  // Running under c4m (directly or C4)
	C4I_C4P  = 0x4,  // Running under c4plus
	C4I_HRT  = 0x10, // High resolution timer
	C4I_SIG  = 0x20, // Signals supported
	C4I_FLT  = 0x40, // Floating point support
	C4I_PROT = 0x80, // Protected mode support
	C4I_TRAPH = 0x400, // A custom trap handler is installed (safe to probe opcodes)
	C4I_C4KE = 0x200, // C4KE is running
};

// Version 3 adds the data MEMSZ field (see C4R_HDR_MEMSZ): the data
// segment's total in-memory size, which may exceed the DATALEN bytes
// actually stored -- the excess is BSS (zero-initialized, occupies no
// image bytes). Version 2 images have no such field; for them MEMSZ is
// taken to equal DATALEN. Both versions load.
//
// At 32 bits the field's eight bytes hold MEMSZ and four more, which a
// v3 object from c4lc or c4fc uses for the size of its BSS (see
// C4R_HDR_BSS): the zero-filled part at the END of MEMSZ, which begins at
// MEMSZ - BSS. Zero there (or v2's 'p' filler) says nothing; c4rlink then
// keeps that module's whole MEMSZ together, as it always did.
enum { C4R__Supported_Version = 3 };

enum {
	C4ROPT_NONE,
	C4ROPT_SYMBOLS,
	// The source map, out of the extension trailer that follows the
	// symbols (docs/c4-explorer.md 2.1): with SYMBOLS only, since the
	// trailer is found by walking them.
	C4ROPT_SRCMAP = 2,
	// The image is to be run, not read: refuse one with words left for
	// a linker (c4r_report_unlinked). An object (.c4o) is all such
	// words, and c4rlink and c4rdump read them through here.
	C4ROPT_RUN = 4
};

#ifndef FILE_OPEN_MODE
enum { FILE_OPEN_MODE = 0x8000 };
#endif

//
// C4R header
//
enum {
	C4R_HDR_SIGNATURE,  // char[3] "C4R" (no null terminator)
	C4R_HDR_VERSION,    // char
	C4R_HDR_WORDBITS,   // char
	C4R_HDR_ENTRY,      // int
	C4R_HDR_CODELEN,    // int
	C4R_HDR_DATALEN,    // int
	C4R_HDR_PATCHLEN,   // int
	C4R_HDR_SYMBOLSLEN, // int
	C4R_HDR_CONSTRUCTLEN, // int
	C4R_HDR_DESTRUCTLEN, // int
	C4R_HDR_MEMSZ,       // int -- data segment total in-memory size (v3+);
	                     //        >= DATALEN, the excess is zero-filled BSS.
	C4R_HDR_BSS,         // int -- of MEMSZ, how much at its end is BSS: the
	                     //        uninitialized globals, no part of an
	                     //        initialized one (v3, 32 bits); 0 for unknown
	C4R_HDR__Sz
};

//
// Patch segment
//

// Patch type. Apart from these, the patch type refers
// to an id in the symbols table.
// CODE/DATA patches land in the code segment (their address is a word
// offset into it); DCODE/DDATA land in the data segment (their address
// is a byte offset into it). The value side names the target segment.
// The data-resident pair exists for initialized globals that hold
// pointers, and for switch jump tables kept in data.
enum {
	C4R_PTYPE_CODE  = -1,  // code word -> code address
	C4R_PTYPE_DATA  = -2,  // code word -> data address
	C4R_PTYPE_DCODE = -3,  // data word -> code address
	C4R_PTYPE_DDATA = -4   // data word -> data address
};

// Patch Structure
enum {
	C4R_PAT_TYPE,       // int, see C4R_PTYPE_
	C4R_PAT_ADDRESS,    // int
	C4R_PAT_VALUE,      // int
	C4R_PAT__Sz
};

//
// Symbols segment
//

// Symbol types
enum { C4R_STYPE_CHAR, C4R_STYPE_INT, C4R_STYPE_PTR };

// Symbol classes
enum { C4R_SCLASS_Num = 128, C4R_SCLASS_Fun, C4R_SCLASS_Sys, C4R_SCLASS_Glo, C4R_SCLASS_Loc, C4R_SCLASS_Id };

// Symbol structure
enum {
	C4R_SYMB_ID,         // int
	C4R_SYMB_TYPE,       // char, CHAR or INT, optionally plus any number of PTR
	C4R_SYMB_CLASS,      // char, see Symbol classes
	C4R_SYMB_ATTRS,      // int, attributes
	C4R_SYMB_NAMELEN,    // char
	C4R_SYMB_NAME,       // char *
	C4R_SYMB_VALUE,      // int
	//C4R_SYMB_LENGTH,     // int, used for functions only currently
	C4R_SYMB__Sz
};

//
// Construct / Destruct segment
//

// Construct / Destruct structure
enum {
	C4R_CNDE_Priority,   // int, lowest runs first
	C4R_CNDE_Value,      // int, address of function (not adjusted for code load addr)
	C4R_CNDE__Sz
};

//
// Structure with references to all the above
//
enum {
	C4R_FILENAME,
	C4R_HEADER,
	C4R_CODE,
	C4R_DATA,
	C4R_PATCHES,
	C4R_SYMBOLS,
	C4R_CONSTRUCTORS,
	C4R_DESTRUCTORS,
	C4R_LOADCOMPLETE,
	C4R_SRCMAP,         // char *: the SMAP chunk's payload (C4ROPT_SRCMAP), or 0
	C4R_SRCMAPLEN,      // its length in bytes
	C4R__Sz
};

//
// C4R Interface
//

enum { C4R_BUFFER_SIZE = 255 };

int c4r_debug, c4r_verbose, c4r_fullmode;

// Convert up to 4 characters into a single word
int c4r__charword (char a, char b, char c, char d) {
	return a + ((b) << 8) + ((c) << 16) + ((d) << 24);
}

char *c4r_strcpy_alloc (char *source) {
	int len;
	char *result, *p, *x;

	// Count chars
	len = 0; p = source; while (*p++) ++len;
	if (!(result = p = malloc(len + 2)))
		return 0;
	// Copy
	p = source; x = result;
	while (*x++ = *p++)
		; // Empty
	// *x = 0;
	return result;
}

// Memory-source support: when c4r_mem_src is set, c4r_src_read consumes
// from it instead of the file descriptor. This is how C4KE loads programs
// straight out of the kernel's RAM filesystem: c4r_load_mem() below sets
// the cursor and the whole reader runs unchanged.
char *c4r_mem_src;
int   c4r_mem_len, c4r_mem_pos;

int c4r_src_read (int fd, char *buffer, int len) {
	int n;
	if (!c4r_mem_src)
		return read(fd, buffer, len);
	n = c4r_mem_len - c4r_mem_pos;
	if (n <= 0) return 0;
	if (n > len) n = len;
	len = 0;
	while (len < n) { buffer[len] = c4r_mem_src[c4r_mem_pos + len]; ++len; }
	c4r_mem_pos = c4r_mem_pos + n;
	return n;
}

int c4r_readoffset;

// One global to fill in: when c4r_inject_name is set, a load (keeping
// the symbols or not) walks the symbol section and writes
// c4r_inject_value into the image's global of that name, if it has one. This is how C4KE tells a program built for
// the bare machine that it is a task (__c4ke_exit, src/c4ix/libc/bare.c),
// as C4DOS writes __c4dos_api.
char *c4r_inject_name;
int   c4r_inject_value;
int c4r_checked_read (int fd, char *buffer, int len) {
	int i;
	if ((i = c4r_src_read(fd, buffer, len)) <= 0) {
		if (c4r_debug) printf("lc4r: error, read() returned %d\n", i);
	} else {
		if (c4r_debug) printf("lc4r: successful read of %d bytes from file.0x%lx\n", len, c4r_readoffset);
		c4r_readoffset = c4r_readoffset + len;
	}
	return i;
}

void c4r_dump_patches (int *c4r) {
	int *header, *patch, i, max;

	i = 0;
	header = (int *)c4r[C4R_HEADER];
	max = header[C4R_HDR_PATCHLEN];
	patch = (int *)c4r[C4R_PATCHES];
	while (patch && i++ < max) {
		printf("  patch type ");
		if (patch[C4R_PAT_TYPE] == C4R_PTYPE_CODE) printf("CODE");
		else if(patch[C4R_PAT_TYPE] == C4R_PTYPE_DATA) printf("DATA");
		else if(patch[C4R_PAT_TYPE] == C4R_PTYPE_DCODE) printf("DCODE");
		else if(patch[C4R_PAT_TYPE] == C4R_PTYPE_DDATA) printf("DDATA");
		else printf("symbols[%d]", patch[C4R_PAT_TYPE]);
		printf(" address 0x%x value 0x%x\n", patch[C4R_PAT_ADDRESS], patch[C4R_PAT_VALUE]);
		patch = patch + C4R_PAT__Sz;
	}
}

void c4r_dump_symbols (int *c4r) {
	int *header, *symbol, i, max;

	i = 0;
	header = (int *)c4r[C4R_HEADER];
	max = header[C4R_HDR_SYMBOLSLEN];
	symbol = (int *)c4r[C4R_SYMBOLS];
	while (symbol && i++ < max) {
		printf("  symbol %d '%.*s': ", symbol[C4R_SYMB_ID], symbol[C4R_SYMB_NAMELEN], (char *)symbol[C4R_SYMB_NAME]);
		printf("type %d class %d value %d (0x%x) ",
			   symbol[C4R_SYMB_TYPE], symbol[C4R_SYMB_CLASS], symbol[C4R_SYMB_VALUE], symbol[C4R_SYMB_VALUE]);
		printf("attrs 0x%x\n", symbol[C4R_SYMB_ATTRS]);
		symbol = symbol + C4R_SYMB__Sz;
	}
}

void c4r_dump_info (int *c4r) {
	int *header;
	char *c;

	header = (int *)c4r[C4R_HEADER];
	printf("lc4r: C4R ");
	if (c4r[C4R_LOADCOMPLETE]) printf("(loaded)");
	else                       printf("(**error**)");
	printf(" @ 0x%lx with header 0x%lx\n", c4r, header);
	c = (char *)&header[C4R_HDR_SIGNATURE];
	printf("lc4r: Signature %c%c%c  ", *c, *(c + 1), *(c + 2));
	printf("Version %d  ", header[C4R_HDR_VERSION]);
	printf("(%d bits):\n", header[C4R_HDR_WORDBITS]);
	printf("lc4r:");
	if (header[C4R_HDR_ENTRY] == -1)
		printf("   No Entry");
	else
		printf("  Entry = 0x%x", header[C4R_HDR_ENTRY]);
	printf("  Code = %d", header[C4R_HDR_CODELEN]);
	printf("  Data = %d", header[C4R_HDR_DATALEN]);
	if (header[C4R_HDR_MEMSZ] > header[C4R_HDR_DATALEN])
		printf(" (mem %d, +%d bss)", header[C4R_HDR_MEMSZ],
		       header[C4R_HDR_MEMSZ] - header[C4R_HDR_DATALEN]);
	printf("  Patch = %d", header[C4R_HDR_PATCHLEN]);
	printf("  Symbols = %d%s" ,header[C4R_HDR_SYMBOLSLEN], header[C4R_HDR_SYMBOLSLEN] ? "" : " (stripped)");
	printf("  Cons = %d", header[C4R_HDR_CONSTRUCTLEN]);
	printf("  Des  = %d\n", header[C4R_HDR_DESTRUCTLEN]);
	printf("lc4r:  0x%lx\n", c4r[C4R_CODE] + header[C4R_HDR_ENTRY]);

	//c4r_dump_symbols(c4r);
}


// static
enum {
	C4R_BAD_NONE         = 0x0,
	C4R_BAD_CODE         = 0x1,
	C4R_BAD_DATA         = 0x2,
	C4R_BAD_PATCHES      = 0x4,
	C4R_BAD_SYMBOLS      = 0x8,
	C4R_BAD_CONSTRUCTORS = 0x10,
	C4R_BAD_DESTRUCTORS  = 0x20
};

int *c4r_create_empty () {
	int *c4r, *header;
	int  i;
	if (!(c4r = malloc((i = sizeof(int) * C4R__Sz))))
		return 0;
	memset(c4r, 0, i);
	if (!(header = malloc((i = sizeof(int) * C4R_HDR__Sz)))) {
		free(c4r);
		return 0;
	}
	header[C4R_HDR_SIGNATURE]    = c4r__charword('C', '4', 'R', 0);
	header[C4R_HDR_VERSION]      = C4R__Supported_Version;
	header[C4R_HDR_WORDBITS]     = sizeof(int) * 8;
	header[C4R_HDR_ENTRY]        = -1; // No entry (TODO: make enum/constant)
	header[C4R_HDR_CODELEN]      = 0;
	header[C4R_HDR_DATALEN]      = 0;
	header[C4R_HDR_PATCHLEN]     = 0;
	header[C4R_HDR_CONSTRUCTLEN] = 0;
	header[C4R_HDR_DESTRUCTLEN]  = 0;
	header[C4R_HDR_SYMBOLSLEN]   = 0;
	c4r[C4R_HEADER]       = (int)header;
	c4r[C4R_CODE]         = 0;
	c4r[C4R_DATA]         = 0;
	c4r[C4R_SYMBOLS]      = 0;
	c4r[C4R_LOADCOMPLETE] = 1;
	c4r[C4R_CONSTRUCTORS] = 0;
	c4r[C4R_DESTRUCTORS]  = 0;
	return c4r;
}

// The extension trailer (docs/c4-explorer.md 2.1): after S, a word 'X',
// then chunks of a tag word (four ASCII bytes, low first), a length word
// and that many bytes padded to a word, up to a 0 tag. The source map
// (SMAP) is kept in C4R_SRCMAP; any other chunk is skipped. No trailer,
// or a damaged one, leaves the image as loaded: nothing a loader needs
// is in it.
void c4r_read_trailer (int fd, int *c4r, char *buffer, int wordbytes) {
	int tag, len, pad;
	char *p;
	memset(buffer, 0, wordbytes);
	if (c4r_src_read(fd, buffer, wordbytes) < wordbytes || *buffer != 'X') return;
	while (1) {
		memset(buffer, 0, wordbytes);
		if (c4r_src_read(fd, buffer, wordbytes) < wordbytes) return;
		if (!(tag = *(int *)buffer)) return;
		memset(buffer, 0, wordbytes);
		if (c4r_src_read(fd, buffer, wordbytes) < wordbytes) return;
		len = *(int *)buffer;
		if (len < 0 || len > 16777216) return;
		if (!(p = malloc(len + 1))) return;
		if (len && c4r_src_read(fd, p, len) < len) { free(p); return; }
		pad = (wordbytes - len % wordbytes) % wordbytes;
		if (pad) c4r_src_read(fd, buffer, pad);
		if (tag == c4r__charword('S', 'M', 'A', 'P') && !c4r[C4R_SRCMAP]) {
			c4r[C4R_SRCMAP] = (int)p;
			c4r[C4R_SRCMAPLEN] = len;
		} else free(p);
	}
}

// An image that refers to a name it does not define: a patch that names
// a symbol (its type a symbol id, or DSYM). A C4IX program is full
// of them -- each call into its shared libc, which src/c4ix/loader.c
// links at load -- and nothing here links anything, so the word would
// stay as the compiler left it, 0, and the first call through it would
// jump to address 0. (A C4KE that took /bench in C4IX's root for its own
// bench ran C4IX's that way, and under libjs that is ROM: it spun there
// silently.) With C4ROPT_RUN, the load fails; this says what the image
// wanted, by name when the symbols were read.
void c4r_report_unlinked (char *file, int *symbols, int nsyms, int count, int id) {
	int *s, i;
	s = symbols;
	i = 0;
	while (s && i < nsyms && s[C4R_SYMB_ID] != id) { s = s + C4R_SYMB__Sz; ++i; }
	printf("lc4r: '%s' needs ", file);
	if (s && i < nsyms) printf("'%s'", (char *)s[C4R_SYMB_NAME]);
	else printf("symbol %d", id);
	printf(" (%d reference%s to link), which it does not define and no loader here links", count, count == 1 ? "" : "s");
	printf(" -- a C4IX program? Not loading it.\n");
}

int *c4r_load_opt_real (char *file, int options) {
	int fd, i, x;
	int unlinked, unlinked_id;
	char *buffer;
	int *c4r, *header, *code, *data, *patches, *symbols, *constructors, *destructors;
	int  wordbytes, bad;
	int *base, *target;
	int  loop_target;
	char *tmp;
	int  ptype, paddr, pvalu;
	int  percent, p, pc;

	if (!(buffer = malloc(C4R_BUFFER_SIZE))) {
		printf("Failed to allocate %d bytes for read buffer\n", C4R_BUFFER_SIZE);
		return 0;
	}
	memset(buffer, 0, C4R_BUFFER_SIZE);
	if (!(c4r = malloc((i = sizeof(int) * C4R__Sz)))) {
		free(buffer);
		printf("lc4r: Failed to allocate %d bytes for c4r structure\n", i);
		return 0;
	}
	memset(c4r, 0, i);
	if (!(header = malloc((i = sizeof(int) * C4R_HDR__Sz)))) {
		free(buffer);
		free(c4r);
		printf("lc4r: Failed to allocate %d bytes for header structure\n", i);
		return 0;
	}
	memset(header, 0, i);

	c4r[C4R_LOADCOMPLETE] = 0;
	c4r[C4R_FILENAME] = (int)c4r_strcpy_alloc(file);

	// These will be set correctly later
	code = data = patches = symbols = constructors = destructors = 0;
	unlinked = unlinked_id = 0;

	if (c4r_debug || c4r_verbose) printf("lc4r: loading '%s'...\n", file);
	fd = -1;
	if (!c4r_mem_src) {
		// Everything above goes back. C4KE's loader tries the bare name
		// before the one with .c4r on every program it starts, so this
		// is the usual path, not a rare one, and it kept 349 bytes a time.
		if ((fd = open(file, FILE_OPEN_MODE)) < 0) {
			free((char *)c4r[C4R_FILENAME]);
			free(header);
			free(c4r);
			free(buffer);
			return 0;
		}
	}

	//
	// Read header
	//
	if ((i = c4r_checked_read(fd, buffer, 3)) < 3) {
		// printf("lc4r: Shallow c4r_checked_read of first 3 bytes\n");
	} else {
		if (!(buffer[0] == 'C' && buffer[1] == '4' && buffer[2] == 'R')) {
			// Squelched so that running c4 from eshell doesn't complain
			// printf("lc4r: Signature mismatch: '%.3s' != correct 'C4R'\n", buffer);
		} else {
			//
			// Header section
			//
			if (c4r_verbose) printf("lc4r: load header...\n");
			header[C4R_HDR_SIGNATURE] = c4r__charword('C', '4', 'R', 0);
			c4r_src_read(fd, buffer, 1); header[C4R_HDR_VERSION] = *buffer;
			c4r_src_read(fd, buffer, 1); header[C4R_HDR_WORDBITS]= *buffer;
			// The 8 padding bytes after magic+version+wordbits are,
			// as of format v3, the data MEMSZ field (a word at byte
			// offset 5). v2 wrote 'p' filler here; for v2 images MEMSZ
			// is fixed up to DATALEN below.
			i = sizeof(int) - 1;
			x = (5 + i) & ~i;
			c4r_src_read(fd, buffer, x); // padding word: MEMSZ (v3+)
			header[C4R_HDR_MEMSZ] = *(int *)buffer;
			// and at 32 bits, the BSS size beside it ('pppp' in v2)
			header[C4R_HDR_BSS] = 0;
			if (x == 8 && sizeof(int) == 4 && *(int *)(buffer + 4) != 1886417008)
				header[C4R_HDR_BSS] = *(int *)(buffer + 4);
			wordbytes = header[C4R_HDR_WORDBITS] / 8;
			c4r_src_read(fd, buffer, wordbytes); header[C4R_HDR_ENTRY] = *(int *)buffer;
			c4r_src_read(fd, buffer, wordbytes); header[C4R_HDR_CODELEN] = *(int *)buffer;
			c4r_src_read(fd, buffer, wordbytes); header[C4R_HDR_DATALEN] = *(int *)buffer;
			c4r_src_read(fd, buffer, wordbytes); header[C4R_HDR_PATCHLEN] = *(int *)buffer;
			c4r_src_read(fd, buffer, wordbytes); header[C4R_HDR_SYMBOLSLEN] = *(int *)buffer;
			c4r_src_read(fd, buffer, wordbytes); header[C4R_HDR_CONSTRUCTLEN] = *(int *)buffer;
			c4r_src_read(fd, buffer, wordbytes); header[C4R_HDR_DESTRUCTLEN] = *(int *)buffer;
			c4r[C4R_HEADER] = (int)header;

			if (wordbytes != sizeof(int)) {
				// Partial success, but word bit mismatch.
				printf("lc4r: error, c4r file uses %dbit words and we use %dbit.\n",
				       header[C4R_HDR_WORDBITS], sizeof(int) * 8);
				return c4r;
			}
			// Accept the current version and the immediately prior one
			// (v2 has no MEMSZ field -- its "padding word" is filler,
			// so MEMSZ = DATALEN for it: no BSS).
			else if (header[C4R_HDR_VERSION] &&
			         header[C4R_HDR_VERSION] != C4R__Supported_Version &&
			         header[C4R_HDR_VERSION] != C4R__Supported_Version - 1) {
				printf("lc4r: error, c4r file uses version %d and we support only %d\n",
				       header[C4R_HDR_VERSION], C4R__Supported_Version);
				return c4r;
			}
			if (header[C4R_HDR_VERSION] < C4R__Supported_Version)
				header[C4R_HDR_MEMSZ] = header[C4R_HDR_DATALEN];
			// A malformed/short MEMSZ must never be smaller than what is
			// actually stored.
			if (header[C4R_HDR_MEMSZ] < header[C4R_HDR_DATALEN])
				header[C4R_HDR_MEMSZ] = header[C4R_HDR_DATALEN];
			// nor a BSS that would start before the stored bytes end
			if (header[C4R_HDR_VERSION] < C4R__Supported_Version || header[C4R_HDR_BSS] < 0 ||
			    header[C4R_HDR_MEMSZ] - header[C4R_HDR_BSS] < header[C4R_HDR_DATALEN])
				header[C4R_HDR_BSS] = 0;

			if (c4r_verbose) c4r_dump_info(c4r);

			//
			// Segment section
			//

			// Allocate and read segments
			if (c4r_verbose) printf("lc4r: allocate memory...\n");
			bad = C4R_BAD_NONE;
			if (!(code = malloc((i = sizeof(int) * header[C4R_HDR_CODELEN]))))
				bad = C4R_BAD_CODE;
			else memset(code, 0, i);
			if (c4r_verbose) printf("lc4r: %ld code allocated\n", i);
			// Allocate the full in-memory size (MEMSZ >= DATALEN) and
			// zero it, so the unstored tail [DATALEN, MEMSZ) is BSS --
			// zero-filled and ready, having cost no image bytes. Only
			// DATALEN bytes are read from the file, below.
			if (header[C4R_HDR_MEMSZ]) {
				if (!(data = malloc((i = sizeof(char)* header[C4R_HDR_MEMSZ]))))
					bad = bad | C4R_BAD_DATA;
				else memset(data, 0, i);
			}
			if (c4r_verbose) printf("lc4r: %ld data allocated\n", i);
			if (header[C4R_HDR_PATCHLEN]) {
				if (!(patches = malloc((i = sizeof(int) * C4R_PAT__Sz * header[C4R_HDR_PATCHLEN]))))
					bad = bad | C4R_BAD_PATCHES;
				else memset(patches, 0, i);
			}
			if (c4r_verbose) printf("lc4r: %ld patches allocated\n", i);
			if (header[C4R_HDR_SYMBOLSLEN]) {
				if (!(symbols = malloc((i = sizeof(int) * C4R_SYMB__Sz * header[C4R_HDR_SYMBOLSLEN]))))
					bad = bad | C4R_BAD_SYMBOLS;
				else memset(symbols, 0, i);
			}
			if (c4r_verbose) printf("lc4r: %ld symbols allocated\n", i);
			if (header[C4R_HDR_CONSTRUCTLEN]) {
				if (!(constructors = malloc((i = sizeof(int) * C4R_CNDE__Sz * header[C4R_HDR_CONSTRUCTLEN]))))
					bad = bad | C4R_BAD_CONSTRUCTORS;
				else memset(constructors, 0, i);
			}
			if (c4r_verbose) printf("lc4r: %ld constructors allocated\n", i);
			if (header[C4R_HDR_DESTRUCTLEN]) {
				if (!(destructors  = malloc((i = sizeof(int) * C4R_CNDE__Sz * header[C4R_HDR_DESTRUCTLEN]))))
					bad = bad | C4R_BAD_DESTRUCTORS;
				else memset(destructors, 0, i);
			}
			if (c4r_verbose) printf("lc4r: %ld destructors allocated\n", i);

			if (bad) {
				printf("lc4r: memory allocation failure reason: 0x%x\n", bad);
			} else {
				// Load segments

				// Code
				if (c4r_verbose) printf("lc4r: load code...\n");
				c4r_src_read(fd, buffer, wordbytes); if (*(char *)buffer != 'C') { printf("lc4r: expected code segment, found 0x%x\n", *buffer); return c4r; }
				c4r_src_read(fd, (char *)code, header[C4R_HDR_CODELEN] * wordbytes);
				if (c4r_debug) printf("lc4r: loaded code, now at position 0x%x\n", c4r_readoffset);
				// target = code; i = 0; while (i++ <= header[C4R_HDR_CODELEN]) printf("  Code @ 0x%lx: %d\n", target, *target++);
				c4r[C4R_CODE] = (int)code;
				// Data
				if (c4r_verbose) printf("lc4r: load data...\n");
				c4r_src_read(fd, buffer, wordbytes); if (*(char *)buffer != 'D') { printf("lc4r: expected data segment, found '%c' 0x%x at file position 0x%lx %d\n", *buffer, *buffer, c4r_readoffset, c4r_readoffset); return c4r; }
				c4r_src_read(fd, (char *)data, header[C4R_HDR_DATALEN]);
				//i = 0; x = header[C4R_HDR_DATALEN] / wordbytes; target = data;
				//if (c4r_debug) printf("lc4r: data len %d = %d words\n", header[C4R_HDR_DATALEN], x);
				//while (i++ < x) {
				//	c4r_src_read(fd, buffer, wordbytes);
				//	*target++ = *(int *)buffer;
				//	*(int *)buffer = 0;
				//}
				if (c4r_debug) {
					printf("lc4r: loaded data @ 0x%X, now at position 0x%x\n", data, c4r_readoffset);
					printf("lc4r: Data: '%.*s'\n", header[C4R_HDR_DATALEN], (char *)data);
				}
				c4r[C4R_DATA] = (int)data;
				// Patches
				target = patches; i = 0; loop_target = header[C4R_HDR_PATCHLEN];
				if (c4r_verbose) printf("lc4r: loading and apply %d patches...\n", loop_target);
				c4r_src_read(fd, buffer, wordbytes); if (*(char *)buffer != 'P') { printf("lc4r: expected patch segment, found 0x%x, position 0x%x (%d)\n", *buffer, c4r_readoffset - 1, c4r_readoffset - 1); return c4r; }
				percent = 0;
				// p = __time();
				while (i < loop_target) {
					c4r_src_read(fd, buffer, wordbytes); target[C4R_PAT_TYPE]    = ptype = *(int *)buffer;
					c4r_src_read(fd, buffer, wordbytes); target[C4R_PAT_ADDRESS] = paddr = *(int *)buffer;
					c4r_src_read(fd, buffer, wordbytes); target[C4R_PAT_VALUE]   = pvalu = *(int *)buffer;

					// Perform the patching now
					// if (c4r_debug) printf("Patch %d ", i);
					if (ptype == C4R_PTYPE_CODE) {
						// if (c4r_debug) printf("updating code 0x%lX from 0x%lX to 0x%lX\n",
						//        (code + target[C4R_PAT_ADDRESS]),
						//       *(code + target[C4R_PAT_ADDRESS]),
						//	    (code + target[C4R_PAT_VALUE]));
						*(code + paddr) = (int)(code + pvalu);
					} else if(ptype == C4R_PTYPE_DATA) {
						//if (c4r_debug) printf("updating data 0x%lX from 0x%lX to 0x%lX\n",
						//        (code + target[C4R_PAT_ADDRESS]),
						 //      *(code + target[C4R_PAT_ADDRESS]),
						//	    (code + target[C4R_PAT_VALUE]));
						*(code + paddr) = (int)(((char *)data) + pvalu);
					} else if(ptype == C4R_PTYPE_DCODE) {
						*(int *)(((char *)data) + paddr) = (int)(code + pvalu);
					} else if(ptype == C4R_PTYPE_DDATA) {
						*(int *)(((char *)data) + paddr) = (int)(((char *)data) + pvalu);
					} else if (ptype >= 0 || ptype == -5) {
						// A word only a linker fills in: a symbol id in the type (a
						// code word) or, for -5 (DSYM, c4rlink.c), in the value (a data
						// word). Counted, and the image refused once it is read:
						// c4r_report_unlinked.
						if (!unlinked++) unlinked_id = ptype >= 0 ? ptype : pvalu;
					}

					++i;
					target = target + C4R_PAT__Sz;

					// Whole section disabled (not too useful anyway)
					//
					// if (0 && c4r_verbose && __time() - p >= 1000) {
					//	// Only print every 1s max
                    //    percent = (i * 100) / loop_target;
                    //    printf("lc4r: %d%% patched...\n", percent);
                    //    p = __time();
					// }

				}
				if (c4r_verbose)
					printf("lc4r: 100%% patched\n");
				c4r[C4R_PATCHES] = (int)patches;
				if (c4r_debug) printf("lc4r: loaded patches, now at position 0x%x\n", c4r_readoffset);

				// Constructors
				if (c4r_verbose) printf("lc4r: load constructors and destructors...\n");
				c4r_src_read(fd, buffer, wordbytes);
				if (*(char *)buffer != 'c') {
					printf("lc4r: expected constructors segment, found 0x%x\n", *buffer);
					return c4r;
				}
				target = constructors; i = 0; // Constructors
				while (i++ < header[C4R_HDR_CONSTRUCTLEN]) {
					// c4r_src_read(fd, buffer, wordbytes); target[C4R_CNDE_Priority] = *(int *)buffer;
					c4r_src_read(fd, buffer, wordbytes); target[C4R_CNDE_Value]    = *(int *)buffer;
					// printf("cnde_value=%d\n", target[C4R_CNDE_Value]);
					target = target + C4R_CNDE__Sz;
				}
				c4r[C4R_CONSTRUCTORS] = (int)constructors;
				if (c4r_debug) printf("lc4r: loaded constructors, now at position 0x%x\n", c4r_readoffset);
				// Destructors
				c4r_src_read(fd, buffer, wordbytes);
				if (*(char *)buffer != 'd') {
					if (c4r_debug) printf("lc4r: expected destructors segment, found 0x%x (%c)\n", *buffer, *buffer);
					return c4r;
				}
				target = destructors; i = 0;
				while (i++ < header[C4R_HDR_DESTRUCTLEN]) {
					// c4r_src_read(fd, buffer, wordbytes); target[C4R_CNDE_Priority] = *(int *)buffer;
					c4r_src_read(fd, buffer, wordbytes); target[C4R_CNDE_Value]    = *(int *)buffer;
					target = target + C4R_CNDE__Sz;
				}
				c4r[C4R_DESTRUCTORS] = (int)destructors;
				if (c4r_debug) printf("lc4r: loaded destructors, now at position 0x%x\n", c4r_readoffset);

				// Symbols
				// TODO: symbols end up unaligned, need to write strings with padding.
				if (options & C4ROPT_SYMBOLS) {
					c4r_src_read(fd, buffer, wordbytes); if (*(char *)buffer != 'S') { printf("lc4r: expected symbols segment, found 0x%x\n", *buffer); return c4r; }
					target = symbols; i = 0; loop_target = header[C4R_HDR_SYMBOLSLEN];
					if (c4r_verbose) printf("lc4r: loading %d symbols...\n", loop_target);
					while (i < loop_target) {
						c4r_src_read(fd, buffer, wordbytes); target[C4R_SYMB_ID] = *(int *)buffer;
						c4r_src_read(fd, buffer, wordbytes); target[C4R_SYMB_TYPE] = *(int *)buffer;
						c4r_src_read(fd, buffer, wordbytes); target[C4R_SYMB_CLASS]= *(int *)buffer;
						c4r_src_read(fd, buffer, wordbytes); target[C4R_SYMB_ATTRS] = *(int *)buffer;
						c4r_src_read(fd, buffer, 1); target[C4R_SYMB_NAMELEN] = *buffer;
						memset(buffer, 0, C4R_BUFFER_SIZE); // TODO: write nul terminator
						c4r_src_read(fd, buffer, target[C4R_SYMB_NAMELEN]); target[C4R_SYMB_NAME] = (int)c4r_strcpy_alloc(buffer);
						c4r_src_read(fd, buffer, wordbytes); target[C4R_SYMB_VALUE] = *(int *)buffer;
						//c4r_src_read(fd, buffer, wordbytes); target[C4R_SYMB_LENGTH] = *(int *)buffer;
						if (c4r_inject_name && target[C4R_SYMB_CLASS] == 131) {   // Glo
							tmp = c4r_inject_name; x = (int)target[C4R_SYMB_NAME]; p = 0;
							while (tmp[p] && tmp[p] == ((char *)x)[p]) ++p;
							if (!tmp[p] && !((char *)x)[p])
								*(int *)((char *)data + target[C4R_SYMB_VALUE]) = c4r_inject_value;
						}
						if (c4r_debug) {
							printf("Symbol %d @ 0x%lX:\n  Type: %d\n", i, c4r_readoffset, target[C4R_SYMB_TYPE]);
							printf("  Class: %d", target[C4R_SYMB_CLASS]);
							printf("  Name len: %d", target[C4R_SYMB_NAMELEN]);
							printf("  Name: '%s'", (char *)target[C4R_SYMB_NAME]);
							printf("  Value: %d\n", target[C4R_SYMB_VALUE]);
							//printf("  Length: %d\n", target[C4R_SYMB_LENGTH]);
						}

						++i;
						target = target + C4R_SYMB__Sz;
					}
					if (c4r_debug) printf("lc4r: loaded %d symbols, now at position 0x%x\n", i, c4r_readoffset);
					if (options & C4ROPT_SRCMAP) c4r_read_trailer(fd, c4r, buffer, wordbytes);
				} else if (c4r_inject_name) {
					c4r_src_read(fd, buffer, wordbytes);
					i = 0;
					loop_target = *(char *)buffer == 'S' ? header[C4R_HDR_SYMBOLSLEN] : 0;
					while (i < loop_target) {
						c4r_src_read(fd, buffer, wordbytes);              // id
						c4r_src_read(fd, buffer, wordbytes);              // type
						c4r_src_read(fd, buffer, wordbytes); pc = *(int *)buffer;   // class
						c4r_src_read(fd, buffer, wordbytes);              // attrs
						c4r_src_read(fd, buffer, 1); x = *buffer & 255;   // name length
						memset(buffer, 0, C4R_BUFFER_SIZE);
						c4r_src_read(fd, buffer, x);
						// the name, against c4r_inject_name
						tmp = c4r_inject_name; p = 0;
						while (p < x && tmp[p] && tmp[p] == buffer[p]) ++p;
						p = p == x && !tmp[p];
						c4r_src_read(fd, buffer, wordbytes);              // value
						if (p && pc == 131) {                             // Glo: an offset into data
							*(int *)((char *)data + *(int *)buffer) = c4r_inject_value;
							i = loop_target;
						}
						++i;
					}
				}
				c4r[C4R_SYMBOLS] = (int)symbols;

				// Words left for a linker, in an image to be run: refused,
				// by the failure path below. What only this branch allocated
				// goes first.
				if (unlinked && (options & C4ROPT_RUN)) {
					c4r_report_unlinked(file, (options & C4ROPT_SYMBOLS) ? symbols : 0,
					                    header[C4R_HDR_SYMBOLSLEN], unlinked, unlinked_id);
					if (options & C4ROPT_SYMBOLS) {
						i = 0; target = symbols;
						while (i++ < header[C4R_HDR_SYMBOLSLEN]) {
							if (target[C4R_SYMB_NAME]) free((char *)target[C4R_SYMB_NAME]);
							target = target + C4R_SYMB__Sz;
						}
					}
					if (c4r[C4R_SRCMAP]) free((char *)c4r[C4R_SRCMAP]);
					free((char *)c4r[C4R_FILENAME]);
				} else {
				// Success, cleanup buffer and file, return
				if (c4r_debug) printf("lc4r: Successfully loaded, c4r = 0x%lx  header = 0x%lx\n", c4r, header);
				c4r[C4R_LOADCOMPLETE] = 1;

				free(buffer);
				close(fd);

				if (c4r_verbose) printf("lc4r: load complete.\n");
				return c4r;
				}
			}
		}
	}
	
	// If we reach here, something went wrong, unallocate everything
	if (destructors) free(destructors);
	if (constructors) free(constructors);
	if (symbols) free(symbols);
	if (patches) free(patches);
	if (data) free(data);
	if (code) free(code);
	if (header) free(header);
	if (c4r) free(c4r);
	if (buffer) free(buffer);
	if (fd >= 0) close(fd);

	if (c4r_verbose) printf("lc4r: load failure.\n");

	return 0;
}

char *c4r_load_opt_pure_passthrough_file;
int  c4r_load_opt_pure_passthrough_options;
int  *c4r_load_opt_pure_passthrough () {
	return c4r_load_opt_real(c4r_load_opt_pure_passthrough_file, c4r_load_opt_pure_passthrough_options);
}

int *c4r_load_opt_pure (char *file, int options) {
	c4r_load_opt_pure_passthrough_file = file;
	c4r_load_opt_pure_passthrough_options = options;
	return __c4_invoke((int *)&c4r_load_opt_pure_passthrough);
}

int *c4r_load_opt (char *file, int options) {
	if (1 && __c4_info() & C4I_C4)
		return c4r_load_opt_pure(file, options);
	return c4r_load_opt_real(file, options);
}

// Load a module from a memory buffer (name is recorded for stack traces).
int *c4r_load_mem (char *name, char *buf, int len, int options) {
	int *r;
	c4r_mem_src = buf;
	c4r_mem_len = len;
	c4r_mem_pos = 0;
	r = c4r_load_opt(name, options);
	c4r_mem_src = 0;
	return r;
}

int *c4r_load (char *file) {
	if (1 && __c4_info() & C4I_C4)
		return c4r_load_opt_pure(file, C4ROPT_SYMBOLS);
	return c4r_load_opt(file, C4ROPT_SYMBOLS);
}

// Free all elements of a C4R module
void c4r_free (int *c4r) {
	int i, *s, *h, *d;

	// First all the simple items
	if (c4r[C4R_CODE]) {
		if (c4r_debug) printf("lc4r: freeing code @ 0x%X\n", c4r[C4R_CODE]);
		free((int *)c4r[C4R_CODE]); c4r[C4R_CODE] = 0;
	}
	if (c4r[C4R_DATA]) {
		if (c4r_debug) printf("lc4r: freeing data @ 0x%X\n", c4r[C4R_DATA]);
		free((int *)c4r[C4R_DATA]); c4r[C4R_DATA] = 0;
	}
	if (c4r[C4R_PATCHES]) {
		if (c4r_debug) printf("lc4r: freeing patches @ 0x%X\n", c4r[C4R_PATCHES]);
		free((int *)c4r[C4R_PATCHES]); c4r[C4R_PATCHES] = 0;
	}
	if (c4r[C4R_CONSTRUCTORS]) { free((int *)c4r[C4R_CONSTRUCTORS]); c4r[C4R_CONSTRUCTORS] = 0; }
	if (c4r[C4R_SRCMAP]) { free((char *)c4r[C4R_SRCMAP]); c4r[C4R_SRCMAP] = 0; }
	if (c4r[C4R_DESTRUCTORS]) {
		if (c4r_debug) printf("lc4r: freeing destructors @ 0x%X\n", c4r[C4R_CONSTRUCTORS]);
		free((int *)c4r[C4R_DESTRUCTORS]); c4r[C4R_DESTRUCTORS] = 0;
	}
	// Symbols have a number of allocated strings
	if (c4r[C4R_SYMBOLS]) {
		if (c4r_debug) printf("lc4r: freeing symbols...\n");
		h = (int *)c4r[C4R_HEADER]; // Grab header
		i = 0;
		d = (int *)c4r[C4R_SYMBOLS];
		if (c4r_debug) printf("Freeing %d symbols\n", h[C4R_HDR_SYMBOLSLEN]);
		while (i++ < h[C4R_HDR_SYMBOLSLEN]) {
			if (d[C4R_SYMB_NAME]) {
				free((char *)d[C4R_SYMB_NAME]);
				d[C4R_SYMB_NAME] = 0;
			}
			d = d + C4R_SYMB__Sz;
		}
		free((int *)c4r[C4R_SYMBOLS]);
		c4r[C4R_SYMBOLS] = 0;
	}
	// The header and overall structure
	if (c4r[C4R_HEADER]) {
		if (c4r_debug) printf("lc4r: freeing header @ 0x%X\n", c4r[C4R_HEADER]);
		free((int *)c4r[C4R_HEADER]); c4r[C4R_HEADER] = 0;
	}
	// Allocated by c4r_load() via c4r_strcpy_alloc(); nothing else owns it.
	if (c4r[C4R_FILENAME]) {
		free((char *)c4r[C4R_FILENAME]); c4r[C4R_FILENAME] = 0;
	}
	if (c4r_debug) printf("lc4r: freeing structure @ 0x%X\n", c4r);
	free(c4r);
}

int *c4r_st_bp, *c4r_st_pc;
void c4r_st_get_stack_pointers () {
	int *addr; // grabs us the stack pointer
	c4r_st_bp = (int *)(*(&addr + 1));
	c4r_st_pc = (int *)(*(&addr + 2));
}

// TODO: move these definitions
enum {
	// Opcodes
	LEA ,IMM ,JMP ,JSR ,BZ  ,BNZ ,ENT ,ADJ ,LEV ,LI  ,LC  ,SI  ,SC  ,PSH ,
	OR  ,XOR ,AND ,EQ  ,NE  ,LT  ,GT  ,LE  ,GE  ,SHL ,SHR ,ADD ,SUB ,MUL ,DIV ,MOD ,
	// Syscalls
	OPEN,READ,CLOS,PRTF,MALC,FREE,MSET,MCMP,EXIT,
	// C4M Extended opcodes
	PUTC,PUTS,RALC,MCPY,STRC,
	ITH ,_OPC,_BLT,_TRP,OPCD,
	_JMP,_ADJ,C4CF,C4CY,TIME,
	SIGH,SIGI,USLP,INFO,OPSL,
	// C4 Invoke: call a section of code as if it were a C4 function
	C4IV,
	// Unsupported float instruction
	FLT ,
	// Instructions
	JSRI,JSRS,JMPA,TLEV,DBG ,
	// c4mp's, which this loader names but never executes
	CPUI,CPUN,CPUS,CPUH,
	CAS ,XCHG,FADD,CWAI,CWAK,IPI ,
	LXI ,SXI ,TRAW,
	// The fused opcodes -- docs/fused-opcodes.md. Appended, never
	// inserted: the list index IS the opcode number and it is mirrored
	// across c4m.c, c4l.c, c4mp.h, oisc4.c, c4cc.c and c4r.lisp.
	LDL ,LDG ,PSHL,PSHG,LEAP,IMMP,LIP ,ADDL,STL ,POPA,
	// F3: IEEE arithmetic (docs/c4-float.md)
	FPU ,
	// 16-bit loads and store, logical shift right (docs/c4-16bit.md)
	LH  ,LHU ,SH  ,LSR ,LCU ,
	// End of instructions
	INS_SIZE,
};

// Also sets c4r_st_find_enter_size
int c4r_st_find_enter_size;
int *c4r_st_find_function_entry (int *addr, int *codebegin, int *codebegin_alt) {
	int *next, i, *begin;

	// TODO: this logic broken
	begin = codebegin;
	if (addr < codebegin)
		begin = codebegin_alt;

	if (c4r_verbose)
		printf("load_c4r/c4r_st_find_function_entry: out of %lp and %lp, selected %lp as begin for addr %lp\n",
			   codebegin, codebegin_alt, begin, addr);

	// Find ENT x
	i = 0;
	next = addr;
	while (++i <= ST_FUNC_SEARCH_MAX) {
		//if (c4r_verbose)
		//	printf("c4r_st_find_function_entry, cycle %ld, position @ %lp: %d\n", i - 1, addr, *addr);
		--next;
		if (*addr == ENT) { // Possibly found
			// Ensure it wasn't an argument to some other opcode
			if (c4r_verbose)
				printf("..possibly found @ %lp: %d\n", addr, *addr);
			if (next <= begin || *next > ADJ) {
				c4r_st_find_enter_size = *(addr + 1);
				return addr;
			} else if (c4r_verbose) printf("..next was %d, discarded....but is %lp > %lp?\n", *next, next, begin);
		}
		if ((addr = next) < begin) {
			if (c4r_verbose)
				printf("load_c4r/c4r_st_find_function_entry: reached code begin %lp\n", begin);
			return 0;
		}
	}

	if (c4r_verbose)
		printf("load_c4r/c4r_st_find_function_entry: couldn't find entry\n");
	return 0;
}

int *c4r_st_find_function_by_address (int *c4r, int *address) {
	int *hdr, *code, *syms, syms_length, *sym, *next_sym, i, cls;
	int adjusted;

	hdr  = (int *)c4r[C4R_HEADER];
	if (c4r_verbose)
		printf("  hdr @ %lp\n", hdr);
	code = (int *)c4r[C4R_CODE];
	if (c4r_verbose)
		printf("  code @ %lp\n", code);
	syms = sym = (int *)c4r[C4R_SYMBOLS];
	syms_length = hdr[C4R_HDR_SYMBOLSLEN];
	if (c4r_verbose)
		printf("  syms @ %lp length %ld\n", syms, syms_length);
	next_sym = sym + C4R_SYMB__Sz;
	i = 0;
	if (c4r_verbose)
		printf("c4r_st_find_function_by_address(%lp, %lp): searching through %ld symbols\n",
		       c4r, address, syms_length);
	while (i < syms_length) {
		cls = sym[C4R_SYMB_CLASS];
		if (cls == C4R_SCLASS_Fun) {
			adjusted = address - code - sym[C4R_SYMB_VALUE];
			if (c4r_verbose) {
				printf("  sym %d '%.*s': ", sym[C4R_SYMB_ID], sym[C4R_SYMB_NAMELEN], (char *)sym[C4R_SYMB_NAME]);
				printf("type %d class %d value %ld (0x%lx) ",
					   sym[C4R_SYMB_TYPE], sym[C4R_SYMB_CLASS], sym[C4R_SYMB_VALUE], code + sym[C4R_SYMB_VALUE]);
				printf(" adjusted value %ld (%lp) ", adjusted, adjusted);
				printf("attrs 0x%x\n", sym[C4R_SYMB_ATTRS]);
			}
			if (adjusted == 0)
				return sym;
		} else {
			if (c4r_verbose) {
				printf(" (not a fun) sym %d '%.*s': ", sym[C4R_SYMB_ID], sym[C4R_SYMB_NAMELEN], (char *)sym[C4R_SYMB_NAME]);
				printf("type %d class %d value %ld (0x%lx) ",
					   sym[C4R_SYMB_TYPE], sym[C4R_SYMB_CLASS], sym[C4R_SYMB_VALUE], code + sym[C4R_SYMB_VALUE]);
				printf(" adjusted value %ld (%lp) ", adjusted, adjusted);
				printf("attrs 0x%x\n", sym[C4R_SYMB_ATTRS]);
			}
		}
		++i;
		sym = next_sym;
		next_sym = sym + C4R_SYMB__Sz;
	}

	return 0;
}

enum {
	// Shouldn't get hit, but just in case.
	// See c4r_stacktrace_depth_max.
	C4R_STACKTRACE_DEFAULT_DEPTH_MAX = 50,
	// How much to indent by per function depth
	// See c4r_stacktrace_depth_indent;
	C4R_STACKTRACE_DEFAULT_INDENT = 2
};

int _c4r_stacktrace_setup;
// Holds a large amount of space
char *_c4r_bigWhitespace;
int c4r_stacktrace_depth_max;
int c4r_stacktrace_depth_indent;

void _c4r_stacktrace_perform_setup () {
	// Setup our bigWhitespace and set defaults
	_c4r_bigWhitespace = "                                               "
						 "                                               ";
	if (!c4r_stacktrace_depth_max)
		c4r_stacktrace_depth_max = C4R_STACKTRACE_DEFAULT_DEPTH_MAX;
	if (!c4r_stacktrace_depth_indent)
		c4r_stacktrace_depth_indent = C4R_STACKTRACE_DEFAULT_INDENT;
	_c4r_stacktrace_setup = 1;
}

//C4R_CONSTRUCTOR(_c4r_stacktrace_constructor, c4r) {
int __attribute__((constructor)) _c4r_stacktrace_constructor (int *c4r) {
	_c4r_stacktrace_perform_setup();
}

// Print a stacktrace
// TODO: the whole alt thing makes the logic confusing, and doesn't allow
//       support for multiple modules. Add in a module list.
void c4r_print_stacktrace (int *c4r, int *alt, int *bp, int *pc) {
	int *returnpc, *entrypc, depth;
	int *sym;
	int *hdr, *hdr_alt;
	int *codebegin, *codeend;
	char*databegin, *dataend;
	int *codebegin_alt, *codeend_alt;
	char*databegin_alt, *dataend_alt;
	int  addr, pcvalid;
	char *file;

	depth = 0;

	if (!_c4r_stacktrace_setup) {
		_c4r_stacktrace_perform_setup();
	}

	if (!c4r && alt) {
		c4r = alt;
		alt = 0;
	}

	if (!c4r) {
		printf("stacktrace unavailable: no .c4r symbols loaded\n");
		return;
	}

	if (pc == 0 || bp == 0) {
		c4r_st_get_stack_pointers();
	}
	if (pc == 0) pc = c4r_st_pc;
	if (bp == 0) bp = c4r_st_bp;

	hdr       = (int *)c4r[C4R_HEADER];
	codebegin = (int *)c4r[C4R_CODE];
	codeend   = codebegin + hdr[C4R_HDR_CODELEN]; // already in word size
	databegin = (char *)c4r[C4R_DATA];
	dataend   = databegin + hdr[C4R_HDR_DATALEN];
	if (alt) {
		hdr_alt       = (int *)alt[C4R_HEADER];
		codebegin_alt = (int *)alt[C4R_CODE];
		codeend_alt   = codebegin_alt + hdr_alt[C4R_HDR_CODELEN]; // already in word size
		databegin_alt = (char *)alt[C4R_DATA];
		dataend_alt   = databegin_alt + hdr_alt[C4R_HDR_DATALEN];
	}

	printf("lc4r stacktrace for returnpc %lp with bp %lp, using c4r structure %lp or %lp\n", pc, bp, c4r, alt);
	while (depth < c4r_stacktrace_depth_max) {
		depth = depth + c4r_stacktrace_depth_indent;
		entrypc = c4r_st_find_function_entry(pc, codebegin, codebegin_alt);
		if (!entrypc) {
			printf("could not find function entry within 0x%lx words, stacktrace unavailable\n", ST_FUNC_SEARCH_MAX);
			return;
		}
		if (c4r_verbose) printf(" think entrypc is %lp\n", entrypc);
		if (!(sym = c4r_st_find_function_by_address(c4r, entrypc))) {
			if (!(sym = c4r_st_find_function_by_address(alt, entrypc))) {
				printf("further stacktrace unavailable, not found in %lp either\n", alt);
				return;
			}
			file = (char *)alt[C4R_FILENAME];
			addr = (int)pc - (int)codebegin_alt;
			if (c4r_verbose)
				printf("addr: 0x%lx - 0x%lx = 0x%lx\n", pc, codebegin_alt, addr);
		} else {
			file = (char *)c4r[C4R_FILENAME];
			addr = (int)pc - (int)codebegin;
			if (c4r_verbose)
				printf("addr: 0x%lx - 0x%lx = 0x%lx\n", pc, codebegin, addr);
		}
		// TODO: addr calculation incorrect
		printf("%.*s%s:%.*s()+0x%lx\n", depth, _c4r_bigWhitespace,
		       file,
		       sym[C4R_SYMB_NAMELEN], (char *)sym[C4R_SYMB_NAME],
		       (int)pc - (int)entrypc);
		//printf("type %d class %d value %ld (0x%lx) ",
		//       sym[C4R_SYMB_TYPE], sym[C4R_SYMB_CLASS], sym[C4R_SYMB_VALUE], sym[C4R_SYMB_VALUE]);
		//printf("attrs 0x%x\n", sym[C4R_SYMB_ATTRS]);

		if (!bp) { if (c4r_verbose) printf("ex 1\n"); return; }
		if (!*bp) { if (c4r_verbose) printf("ex 6\n"); return; }

		// printf("test pc value: %d\n", *pc);

		pc = (int *)*(bp + 1);
		bp = (int *)*bp;

		if (!bp) { if (c4r_verbose) printf("ex 4\n"); return; }
		if (!pc) { if (c4r_verbose) printf("ex 5\n"); return; }

		pcvalid = 0;
		if (alt) {
			if (pc >= codebegin_alt && pc <= codeend_alt) {
				pcvalid = 1;
			} else {
				// printf("ex 7, 0x%lx < 0x%lx || 0x%lx > 0x%lx\n", pc, codebegin_alt, pc, codeend_alt);
				if ((char *)pc >= databegin_alt && (char *)pc <= dataend_alt) {
					pcvalid = 1;
				} // else printf("ex 7, 0x%lx < 0x%lx || 0x%lx > 0x%lx\n", pc, databegin_alt, pc, dataend_alt);
			}
		}
		if (!pcvalid) {
			if (pc >= codebegin && pc <= codeend) {
				pcvalid = 1;
			} else {
				// printf("ex 8, 0x%lx < 0x%lx || 0x%lx > 0x%lx\n", pc, codebegin, pc, codeend);
				if ((char *)pc >= databegin && (char *)pc <= dataend) {
					pcvalid = 1;
				} // else printf("ex 8, 0x%lx < 0x%lx || 0x%lx > 0x%lx\n", pc, databegin, pc, dataend);
			}
		}

		if (!pcvalid)
			return;

		// printf("! continuing\n");
	}
}

// This macro satisfies gcc to use c4 syntax of calling function pointers via int*
#ifndef __c4cc__
#define entry(a,b) ((int (*)(int, char**))entry)(a, b)
#define cons(c4r)  ((int (*)(int *))cons)(c4r)
#define des()      ((int (*)())des)()
#endif

// These functions are mainly to help with stack traces, showing
// what stage of a program crashed (constructors, main/entry, destructors).

//
void __loadc4r_execute_cons (int *cons, int *c4r) {
	cons(c4r);
}

//
int __loadc4r_execute_entry (int *entry, int argc, char **argv) {
	return entry(argc, argv);
}

//
void __loadc4r_execute_des (int *des) {
	des();
}

//
// Public interface
//

// Execute a loaded c4r module. Must provide a fully loaded c4r structure.
// Also runs constructors and destructors.
int loadc4r_execute (int *c4r, int argc, char **argv) {
	int *header, *entry;
	int  i, *c, r, *cons, *des, len;

	// Must have a complete structure.
	if (!c4r[C4R_LOADCOMPLETE]) return -1;

	header = (int *)c4r[C4R_HEADER];
	// Must have an entry point
	if (header[C4R_HDR_ENTRY] == -1) {
		printf("lc4r: this module has no entry point.\n");
		return -2;
	}

	entry = (int *)c4r[C4R_CODE] + header[C4R_HDR_ENTRY];
	// printf("lc4r: header @ 0x%x  code @ 0x%x  entry @ 0x%x\n", header, (int *)c4r[C4R_CODE], entry);

    if ((len = header[C4R_HDR_CONSTRUCTLEN])) {
        // Run constructors
        if (c4r_verbose) printf("lc4r: running %d constructors...\n", len);
        c = (int *)c4r[C4R_CONSTRUCTORS];
        i = 0;
        while (i++ < len) { // C4R_HDR_CONSTRUCTLEN
            cons = (int *)c4r[C4R_CODE] + c[C4R_CNDE_Value];
            // printf("lc4r: calling constructor at offset 0x%x, real=0x%x\n", c[C4R_CNDE_Value], cons);
			__loadc4r_execute_cons(cons, c4r);
            c = c + C4R_CNDE__Sz;
        }
    }

	// Call main entry point
	if (c4r_verbose) printf("lc4r: start program...\n");
	r = __loadc4r_execute_entry(entry, argc, argv);

    if ((len = header[C4R_HDR_DESTRUCTLEN])) {
        // Run destructors
        if (c4r_verbose) printf("lc4r: running %d destructors...\n", len);
        c = (int *)c4r[C4R_DESTRUCTORS];
        i = 0;
        while (i++ < len) {
            des = (int *)c4r[C4R_CODE] + c[C4R_CNDE_Value];
            // printf("lc4r: calling destructor at offset 0x%x, real=0x%x\n", c[C4R_CNDE_Value], des);
            __loadc4r_execute_des(des);
            c = c + C4R_CNDE__Sz;
        }
    }

	return r;
}
#ifndef __c4cc__
#undef entry
#undef cons
#undef des
#endif

char *strcpycat (char *source, char *append) {
	int length, slen, alen;
	char *buffer, *s, *d;

	// Count length
	length = slen = alen = 0;
	s = source; while(*s++) ++slen;
	s = append; while(*s++) ++alen;
	length = slen + alen + 1; // nul terminator
	if (!(buffer = malloc(sizeof(char) * length)))
		return 0;
	// Copy source
	s = source; d = buffer; while(*d++ = *s++) ; // empty body
	// rewind
	--d;
	// Copy append
	s = append;             while(*d++ = *s++) ; // empty body
	// terminating nul has already been copied

	return buffer;
}

int loadc4r_run (char *file, int argc, char **argv) {
	int *module, *modules, result;
	char *alt_file;

	alt_file = 0;

	if (!(module = c4r_load_opt(file, C4ROPT_SYMBOLS | C4ROPT_RUN))) {
		// Attempt a version with .c4r appended
		alt_file = strcpycat(file, ".c4r");
		if (!(module = c4r_load_opt(alt_file, C4ROPT_SYMBOLS | C4ROPT_RUN))) {
			printf("lc4r: unable to open '%s' or '%s'\n", file, alt_file);
			free(alt_file);
			return 1;
		}
	}
	// printf("lc4r: module %s loaded\n", alt_file ? alt_file : file);

    if (c4r_verbose)
        c4r_dump_info(module);
	result = -1;
	if (module[C4R_LOADCOMPLETE])
		result = loadc4r_execute(module, argc, argv);
	c4r_free(module);
	if (alt_file) free(alt_file);

	return result;
}

// Aliases to c4r functions
void loadc4r_dump_info (int *c4r) { c4r_dump_info(c4r); }
void loadc4r_free (int *c4r) { c4r_free(c4r); }

enum {
	LC4RF_NONE,
	LC4RF_NO_PARSE
};

void loadc4r_usage () {
    printf("Load C4R usage: ./c4m load-c4r.c [-v] [-d] [--] [file.c4r]\n");
}

#ifndef NO_LOADC4R_MAIN
int main (int argc, char **argv) {
	int result, flags;
	char n;

	result = -1;
	flags = LC4RF_NONE;

	if (argc < 1) {
        loadc4r_usage();
	} else {
		--argc; ++argv;
		while(argc && flags != LC4RF_NO_PARSE && **argv == '-') {
			// printf("option: '%s'\n", *argv);
			n = (*argv)[1];
			if (n == '-')
				flags = LC4RF_NO_PARSE;
			else if (n == 'd')
				c4r_debug = !c4r_debug;
			else if (n == 'v')
				c4r_verbose = !c4r_verbose;
			else {
				printf("load-c4r: unrecognised option: '%s'\n", *argv);
				exit(-1);
			}
			--argc; ++argv;
		}
        if (argc)
            result = loadc4r_run(*argv, argc, argv);
        else {
            loadc4r_usage();
            result = -1;
        }
	}
	return result;
}
#endif
