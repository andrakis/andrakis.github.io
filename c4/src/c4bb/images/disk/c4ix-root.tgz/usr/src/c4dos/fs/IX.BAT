@ECHO OFF
REM At the root of the RAM disk: what is built there is what C4KE is
REM handed when dosload boots it (its init.c4r, not a C4KE\INIT.C4R).
CD \
REM Build C4IX, inside the machine, with the compiled c4lc.
REM
REM Thirteen modules and a link. Each module is one c4sc run: preprocess,
REM parse, tree passes, code generation, peephole passes, and a .c4o
REM object written to the RAM disk. Then c4rlink joins them into a
REM kernel and dosload boots it. About four and a half minutes of
REM simulated hardware -- docs/compiler-on-the-board.md has the cycles.
ECHO ---------------------------------------------
ECHO  Building C4IX with the compiled compiler
ECHO ---------------------------------------------
RUN dostar.c4r x c4ix-src.tar
ECHO [1/13] boot
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/boot.c boot.c4o
ECHO [2/13] console
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/console.c console.c4o
ECHO [3/13] va
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/va.c va.c4o
ECHO [4/13] host
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/host.c host.c4o
ECHO [5/13] sl4b
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/sl4b.c sl4b.c4o
ECHO [6/13] task
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/task.c task.c4o
ECHO [7/13] sched
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/sched.c sched.c4o
ECHO [8/13] vfs
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/vfs.c vfs.c4o
ECHO [9/13] sys
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/sys.c sys.c4o
ECHO [10/13] c4ke
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/c4ke.c c4ke.c4o
ECHO [11/13] loader
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/loader.c loader.c4o
ECHO [12/13] mmu
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/mmu.c mmu.c4o
ECHO [13/13] init
RUN c4sc.c4r -c 200000 compile -O -c -I src/c4ix src/c4ix/init.c init.c4o
ECHO Linking...
RUN c4rlink.c4r @c4ix.objs -o c4ix.c4r
ECHO ---------------------------------------------
ECHO  Built. Type RUN dosload.c4r c4ix.c4r to boot it.
ECHO ---------------------------------------------
