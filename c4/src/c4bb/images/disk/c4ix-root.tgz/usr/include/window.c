// window.c -- window.h's functions (window.h says how to use them).
// Included by window.h, or built into C4IX's shared libc4ix.

#include "window.h"

char *win_out;   // commands waiting to go out
int   win_olen;
char *win_in;    // event bytes read but not yet parsed
int   win_ilen;

// The C4IX system call gate (c4ix_user.h's SYS_* numbers).
int win_sys(int num, int a, int b, int c) { return __c4_opcode(c, b, a, num); }

void win_flush() {
    if (win_olen > 0) win_sys(200, 1, (int)win_out, win_olen);      // SYS_WRITE to stdout
    win_olen = 0;
}

void win_ch(int c) {
    if (win_olen >= WIN_OUTCAP) win_flush();
    win_out[win_olen] = c;
    win_olen = win_olen + 1;
}

void win_str(char *s) { while (*s) { win_ch(*s); s = s + 1; } }

void win_num(int v) {
    if (v < 0) { win_ch('-'); v = 0 - v; }
    if (v >= 10) win_num(v / 10);
    win_ch('0' + v % 10);
}

void win_begin(int op) { win_ch(27); win_ch('_'); win_ch('G'); win_ch(op); }
void win_end() { win_ch(27); win_ch('\\'); }
void win_arg(int v, int more) { win_num(v); if (more) win_ch(','); }

// 1 when stdin and stdout are both pipes, as a window of the desktop's
// gives them: a Terminal, or one the desktop opened for the program alone.
// SYS_FSTAT's ST_MODE (c4ix_user.h): a pipe is S_IFIFO|0666, the console
// S_IFCHR|0666.
int win_here() {
    int *st, k, r;
    st = (int *)malloc(8 * sizeof(int));
    if (!st) return 0;
    r = 1; k = 0;
    while (k < 2) {
        if (win_sys(236, k, (int)st, 8) < 0 || st[6] != 4534) r = 0;
        k = k + 1;
    }
    free((char *)st);
    return r;
}

// Become a canvas, titled. 1 on success.
//
// With an input that has ended, the program is a job a Terminal's shell
// ran in the background (sh.c gives one no input, as POSIX's shell does),
// and that Terminal's canvas is its foreground job's: it asks for a
// window of its own instead (op O, with its task id), and the desktop
// gives it that window's pipes as its stdin and stdout (term.c,
// term_adopt). It waits up to 10 seconds for them; with none, 0.
int win_open(char *title) {
    int k;
    // a program in a window draws too: CPU 0, unless it was pinned (sched_softpin).
    // SYS_DISPLAY, DISP_PIN, by the gate here: c4cc builds this file into a program
    // with no libc4ix.
    win_sys(240, 4, 0, 0);
    if (!win_out) {
        win_out = (char *)malloc(WIN_OUTCAP + 16);
        win_in = (char *)malloc(WIN_INCAP + 16);
        if (!win_out || !win_in) return 0;
    }
    win_olen = 0; win_ilen = 0;
    if (win_sys(221, 0, 0, 0) < 0) {                                  // SYS_AVAIL: stdin has ended
        win_begin('O'); win_num(win_sys(209, 0, 0, 0)); win_ch(';');   // SYS_GETPID
        win_str(title); win_end();
        win_flush();
        k = 0;
        while (win_sys(221, 0, 0, 0) < 0) {
            if (k >= 500) return 0;
            win_sleep(20);
            k = k + 1;
        }
    }
    win_begin('o'); win_ch(';'); win_str(title); win_end();
    win_flush();
    return 1;
}

// Back to a terminal. A program that ends without this is fine too.
void win_close() { win_begin('q'); win_end(); win_flush(); }

void win_clear(int rgb) { win_begin('c'); win_arg(rgb, 0); win_end(); }
void win_rect(int x, int y, int w, int h, int rgb) {
    win_begin('r'); win_arg(x, 1); win_arg(y, 1); win_arg(w, 1); win_arg(h, 1); win_arg(rgb, 0); win_end();
}
void win_frame(int x, int y, int w, int h, int rgb) {
    win_begin('R'); win_arg(x, 1); win_arg(y, 1); win_arg(w, 1); win_arg(h, 1); win_arg(rgb, 0); win_end();
}
void win_line(int x0, int y0, int x1, int y1, int rgb) {
    win_begin('l'); win_arg(x0, 1); win_arg(y0, 1); win_arg(x1, 1); win_arg(y1, 1); win_arg(rgb, 0); win_end();
}
void win_disc(int x, int y, int r, int rgb) {
    win_begin('d'); win_arg(x, 1); win_arg(y, 1); win_arg(r, 1); win_arg(rgb, 0); win_end();
}
// size is the font's pixel height (11 is the desktop's own).
void win_text(int x, int y, int rgb, int size, char *s) {
    win_begin('t'); win_arg(x, 1); win_arg(y, 1); win_arg(rgb, 1); win_arg(size, 0);
    win_ch(';'); win_str(s); win_end();
}
// Show what was drawn since the last present, all at once.
void win_present() { win_begin('p'); win_end(); win_flush(); }

// An 8-bit frame: w x h bytes at pixels, pitch bytes a row, through the
// 256 colours (0x00RRGGBB) at pal, scaled to fill the canvas; present to
// show it. The window reads them when it draws, and then sends WIN_FRAME:
// draw the next frame into them only after that, or into other memory.
// The menu bar of a window of the program's own (window.h): menu n, and an
// item of it. Sent with the next frame.
void win_menu(int n, char *title) { win_begin('M'); win_num(n); win_ch(';'); win_str(title); win_end(); }
void win_item(int n, char *label) { win_begin('I'); win_num(n); win_ch(';'); win_str(label); win_end(); }
// the canvas follows the window's size: WIN_SIZE tells each new one
void win_resizable() { win_begin('z'); win_num(1); win_end(); win_flush(); }
// the mouse locked to the canvas at a click, its motion as WIN_REL (on 0: not)
void win_lock(int on) { win_begin('L'); win_num(on != 0); win_end(); win_flush(); }

void win_fb(char *pixels, int w, int h, int pitch, int *pal) {
    win_begin('f'); win_arg((int)pixels, 1); win_arg(w, 1); win_arg(h, 1);
    win_arg(pitch, 1); win_arg((int)pal, 0); win_end();
}

// Sleep, letting the rest of the machine run.
void win_sleep(int ms) { win_sys(220, ms, 0, 0); }                  // SYS_SLEEP

// The next event, or WIN_NONE; never waits. ev[0..2] get its numbers:
// x, y and the button for the mouse (dx, dy and the buttons for WIN_REL);
// keycode, character and modifiers for a key. -1 when stdin has ended (the window was closed).
int win_poll(int *ev) {
    int n, i, j, k, kind, v, neg;
    // take what has arrived
    n = win_sys(221, 0, 0, 0);                                        // SYS_AVAIL on stdin
    if (n < 0 && win_ilen == 0) return 0 - 1;
    if (n > WIN_INCAP - win_ilen) n = WIN_INCAP - win_ilen;
    if (n > 0) {
        n = win_sys(201, 0, (int)(win_in + win_ilen), n);            // SYS_READ
        if (n > 0) win_ilen = win_ilen + n;
    }
    // one whole line, if there is one
    i = 0;
    while (i < win_ilen && win_in[i] != 10) i = i + 1;
    if (i >= win_ilen) {
        if (win_ilen >= WIN_INCAP) win_ilen = 0;    // garbage without an end: drop it
        return WIN_NONE;
    }
    kind = WIN_NONE;
    if (i >= 3 && win_in[0] == 27 && win_in[1] == 'E') {
        k = win_in[2];
        if (k == 'd') kind = WIN_DOWN;
        else if (k == 'u') kind = WIN_UP;
        else if (k == 'm') kind = WIN_MOVE;
        else if (k == 'k') kind = WIN_KEY;
        else if (k == 's') kind = WIN_SIZE;
        else if (k == 'K') kind = WIN_KEYUP;
        else if (k == 'f') kind = WIN_FRAME;
        else if (k == 'c') kind = WIN_MENU;
        else if (k == 'r') kind = WIN_REL;
        j = 3; k = 0;
        while (k < 3) {
            v = 0; neg = 0;
            if (j < i && win_in[j] == '-') { neg = 1; j = j + 1; }
            while (j < i && win_in[j] >= '0' && win_in[j] <= '9') { v = v * 10 + (win_in[j] - '0'); j = j + 1; }
            if (neg) v = 0 - v;
            ev[k] = v;
            k = k + 1;
            if (j < i && win_in[j] == ',') j = j + 1;
        }
    }
    // drop the line
    i = i + 1;
    j = 0;
    while (i < win_ilen) { win_in[j] = win_in[i]; i = i + 1; j = j + 1; }
    win_ilen = j;
    return kind;
}
