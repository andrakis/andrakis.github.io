#!/bin/bash
# test-c4bb.sh - compare the c4bb simulator against native 32-bit c4m.
# Run from the repo root (make test-c4bb). Modeled on test-oisc4.sh.
#
# c4m prints trap chatter when a bare (kernel-less) image probes for
# custom opcodes; that noise is filtered before comparing, exactly as
# the oisc4 tests do. %p prints arena offsets under c4bb (documented),
# so pointer lines are filtered where a test prints them.
#
# Out of contract until their milestone lands:
#   test_customop test_signal test_timekeeping  - M2 trap machinery
#   test_fread                                  - M3 disk device
#   test_crash                                  - STRC stacktraces need symbols

C4BB="node src/c4bb/sim/cli.js"
C4M32="./c4m32 load-c4r.c --"
C4M64="./c4m load-c4r.c --"
IMAGES=src/c4bb/images
FILTER='/^Trap type/d; /missed a trap/d'
fail=0

# render times differ between VMs; compare the text, not the milliseconds
# Wall-clock and cycle-derived figures are host-dependent by nature and
# are not what these comparisons are about: c4bb's malloc/printf live in
# firmware (guest code) where native c4m's are single opcodes, so the
# instruction counts legitimately differ even when every rendered byte
# matches.
NORM='s/rendered in [0-9]*ms/rendered in Xms/; s|f/s [ 0-9]\{5\}|f/s XXXXX|g; s/kc [ 0-9]\{5\}/kc XXXXX/g'

check () {
    name="$1"; shift
    a=$(timeout 300 $C4BB "$@" 2>/dev/null | sed "$NORM")
    b=$(timeout 300 $C4M32 "$@" 2>&1 | sed "$FILTER" | sed "$NORM")
    if [ "$a" = "$b" ]; then
        echo "test-c4bb: $name OK"
    else
        echo "test-c4bb: $name FAILED"
        diff <(echo "$a") <(echo "$b") | head -10
        fail=1
    fi
}

# A 32-bit .c4r pushes one word per printf argument, so on a 32-bit
# host libc %lld reads 8 bytes where the program pushed 4: native
# c4m32 prints stack garbage there. The firmware formatter treats
# length modifiers as no-ops (every c4 value is one word, same as
# c4lm's stdio.h), which is the well-defined semantic - so tests that
# use %lld are compared against 64-bit native c4m, where %lld and
# "one word" agree.
check64 () {
    name="$1"; img32="$2"; img64="$3"
    a=$(timeout 300 $C4BB "$img32" 2>/dev/null)
    b=$(timeout 300 $C4M64 "$img64" 2>&1 | sed "$FILTER")
    if [ "$a" = "$b" ]; then
        echo "test-c4bb: $name OK (vs 64-bit baseline)"
    else
        echo "test-c4bb: $name FAILED"
        diff <(echo "$a") <(echo "$b") | head -10
        fail=1
    fi
}

for t in hello32 test_basic test_static test_vprintf tests \
         multifun test-order test-ptrs test_continue test_exit \
         test_printloop mandel test_float; do
    check "$t" $IMAGES/$t.c4r
done
# The web front-end's two pieces of real logic: the terminal's screen
# model (cursor addressing, deferred wrap) and the drive set (what is in
# each drive, and what a soft reset does about an eject). Pure JS, no
# machine involved, so they run first and fail fast.
node src/c4bb/tests/test-terminal.mjs || fail=1
node src/c4bb/tests/test-drives.mjs   || fail=1

check cycles $IMAGES/cycles.c4r      # exact cycle-counter parity

# raycast: 20 frames of integer DDA, fixed seed, demo mode (which reads
# no input, so the run is a pure function of its arguments). This is
# the sharpest 32-bit check in the suite -- every Q12 intermediate in
# the renderer is budgeted to stay under 2^30 precisely so c4bb's
# 32-bit words and native 64-bit ones agree, and a budget that is wrong
# shows up here as a frame diff rather than as a picture that merely
# looks a bit odd. f/s is wall-clock and is normalised away by $NORM.
check raycast $IMAGES/disk/raycast.c4r 21x21 -s 7 -d -n 20 -g 80x22

# trap machinery: custom opcodes via ILLOP, preemption timer,
# protected mode (see src/ for why test_customop can't be used)
for t in bb_customop bb_preempt bb_pm; do
    check "$t" $IMAGES/$t.c4r
done

check64 factorial   $IMAGES/factorial.c4r   src/tests/factorial.c4r
check64 test_malloc $IMAGES/test_malloc.c4r src/tests/test_malloc.c4r

# test_args and test_printf segfault native c4m32 (pre-existing 32-bit
# c4m bug in the missed-trap path); compare against 64-bit native with
# argv[0] path and %p pointer lines normalized.
argnorm () { sed 's|src/c4bb/images/|src/tests/|; /an int ptr/d'; }
a=$(timeout 300 $C4BB $IMAGES/test_args.c4r arg1 arg2 2>/dev/null | argnorm)
b=$(timeout 300 $C4M64 src/tests/test_args.c4r arg1 arg2 2>&1 | sed "$FILTER" | argnorm)
if [ "$a" = "$b" ]; then echo "test-c4bb: test_args OK (vs 64-bit baseline)"; else
    echo "test-c4bb: test_args FAILED"; diff <(echo "$a") <(echo "$b") | head -10; fail=1; fi
a=$(timeout 300 $C4BB $IMAGES/test_printf.c4r 2>/dev/null | argnorm)
b=$(timeout 300 $C4M64 src/tests/test_printf.c4r 2>&1 | sed "$FILTER" | argnorm)
if [ "$a" = "$b" ]; then echo "test-c4bb: test_printf OK (vs 64-bit baseline)"; else
    echo "test-c4bb: test_printf FAILED"; diff <(echo "$a") <(echo "$b") | head -10; fail=1; fi

# C4KE boots on the machine: grep assertions in the style of make test
# (interleavings differ from native, so no byte diff here)
c4ke_out=$(printf 'hello.c4r\n\\q\n' | timeout 300 $C4BB -c 30000000 -d $IMAGES/disk $IMAGES/c4ke32.c4r 2>/dev/null)
for want in "c4ke v" "entering task scheduling" "C4SH - The C4 SHell" "yello"; do
    if echo "$c4ke_out" | grep -q "$want"; then
        echo "test-c4bb: c4ke-boot '$want' OK"
    else
        echo "test-c4bb: c4ke-boot '$want' FAILED"; fail=1
    fi
done

# the C4KE filesystem: vfsload populates ramfs from c4ke.vfs.txt at
# boot (see init.c), ls/cat then read it back for real. The entry
# count isn't pinned (it moves whenever the manifest grows), but every
# referenced file must resolve - "cannot open"/"target not found"
# means the manifest and the disk have drifted apart.
#
# These used to be one command per session because a second one was
# silently dropped, and that was read as a c4sh bug: its non-blocking
# reader keeps only what precedes the first '\n'. It is not. A real
# terminal in canonical mode returns AT MOST ONE LINE per read, to
# every reader, blocking or not - so c4sh's assumption is the correct
# one and the line discipline was the layer at fault (kbdRead broke on
# the newline only on the blocking path; docs/dos-rung-fixes.md F18).
# The two-command leg below is here so that cannot come back.
# -a is the flat listing: ls now infers directories from the names and
# shows one level (basenames), so the full paths this pin is about are
# what -a prints. The one-level form gets its own check below.
c4ke_ls_out=$(printf 'ls -a /usr/src/bin\n\\q\n' | timeout 300 $C4BB -c 30000000 -d $IMAGES/disk $IMAGES/c4ke32.c4r 2>/dev/null)
loaded_counts=$(echo "$c4ke_ls_out" | grep -oE '[0-9]+/[0-9]+ entries loaded')
ok_n="${loaded_counts%%/*}"; total_n="${loaded_counts#*/}"; total_n="${total_n%% entries*}"
if [ -n "$loaded_counts" ] && [ "$ok_n" = "$total_n" ] && [ -n "$total_n" ]; then
    echo "test-c4bb: c4ke-vfs full manifest loaded OK ($loaded_counts)"
else
    echo "test-c4bb: c4ke-vfs full manifest loaded FAILED (got '$loaded_counts')"
    echo "$c4ke_ls_out" | grep -E 'cannot open|target not found|entries loaded' | head -10
    fail=1
fi
if echo "$c4ke_ls_out" | grep -qF "/usr/src/bin/ls.c"; then
    echo "test-c4bb: c4ke-vfs ls listing OK"
else
    echo "test-c4bb: c4ke-vfs ls listing FAILED"; fail=1
fi

# And the default: one level, directories as names ending in '/', which
# is what makes the root readable on an 80-column console at all.
c4ke_lsdir_out=$(printf 'ls /usr\n\\q\n' | timeout 300 $C4BB -c 30000000 -d $IMAGES/disk $IMAGES/c4ke32.c4r 2>/dev/null)
if echo "$c4ke_lsdir_out" | grep -qE '(^| )src/' && \
   ! echo "$c4ke_lsdir_out" | grep -qF "/usr/src/bin/ls.c"; then
    echo "test-c4bb: c4ke-vfs ls one level OK"
else
    echo "test-c4bb: c4ke-vfs ls one level FAILED"; fail=1
    echo "$c4ke_lsdir_out" | tail -5
fi

# A task killed for raising an opcode nobody implements must not take
# the shell with it, and its trace must name a real function. This is a
# SMOKE test, not a regression test for F17: on a quiet boot the word
# the out-of-range index lands on is zero, so a kernel without the
# bounds check passes this too (checked, by building one). See
# src/c4ke/bin/badop.c.
c4ke_badop_out=$(printf 'badop.c4r\necho survived-the-kill\n\\q\n' | timeout 300 $C4BB -c 60000000 -d $IMAGES/disk $IMAGES/c4ke32.c4r 2>/dev/null)
if echo "$c4ke_badop_out" | grep -qF "Custom opcode not found: 9001" && \
   ! echo "$c4ke_badop_out" | grep -qF "STILL RUNNING" && \
   echo "$c4ke_badop_out" | grep -qF "badop.c4r:main()" && \
   echo "$c4ke_badop_out" | grep -qF "survived-the-kill" && \
   echo "$c4ke_badop_out" | grep -qF "clean shutdown"; then
    echo "test-c4bb: c4ke survives a task killed on a bad opcode OK"
else
    echo "test-c4bb: c4ke survives a task killed on a bad opcode FAILED"; fail=1
    echo "$c4ke_badop_out" | tail -10
fi

# A task that breaks its own stack guard, both ways (src/c4ke/bin/overrun.c).
# The report must tell a recursion that ran off the bottom of the stack
# and came back from a stray write, though both leave SP near the top
# when the kernel looks at exit -- "44 bytes used, guard broken" was
# read as a stray write when the climb's case was c4sc recursing. And
# the shell must survive both, the recursion stopping inside the guard.
c4ke_deep_out=$(printf 'overrun.c4r\necho survived-the-overrun\n\\q\n' | timeout 300 $C4BB -c 200000000 -d $IMAGES/disk $IMAGES/c4ke32.c4r 2>/dev/null)
c4ke_stray_out=$(printf 'overrun.c4r stray\necho survived-the-overrun\n\\q\n' | timeout 300 $C4BB -c 60000000 -d $IMAGES/disk $IMAGES/c4ke32.c4r 2>/dev/null)
if echo "$c4ke_deep_out" | grep -qF "OVERRAN ITS STACK" && \
   echo "$c4ke_deep_out" | grep -qF "its stack is used to the bottom" && \
   echo "$c4ke_deep_out" | grep -qF "found as it exited" && \
   echo "$c4ke_deep_out" | grep -qF "survived-the-overrun" && \
   echo "$c4ke_stray_out" | grep -qF "1 of 64 guard words broken" && \
   echo "$c4ke_stray_out" | grep -qF "its stack was never used below" && \
   echo "$c4ke_stray_out" | grep -qF "survived-the-overrun"; then
    echo "test-c4bb: c4ke tells a stack that ran off its bottom from a stray write OK"
else
    echo "test-c4bb: c4ke tells a stack that ran off its bottom from a stray write FAILED"; fail=1
    echo "$c4ke_deep_out" | grep -a "overrun\|c4ke: task\|c4ke:   \|survived" | head -8
    echo "$c4ke_stray_out" | grep -a "overrun\|c4ke: task\|c4ke:   \|survived" | head -8
fi

# The lockup that could not be interrupted: a TLEV whose frame restores
# its own address. A unit test on a machine the test builds, because the
# alternative is waiting for a corrupted frame to turn up, and a test
# that waits for a bug is not a test.
node src/c4bb/tests/test-tlev-wedge.mjs || fail=1

# The provenance port (src/c4bb/sim/arena-whowrote.js), both ways.
#
# The pin is NOT "an answer came back" -- a constant would pass that.
# It is that two stores from two different functions produce two
# DIFFERENT non-zero PCs, which is the only thing that makes the port
# useful for chasing a write nobody owns up to. And that without the
# flag the port is silent, because those addresses are ordinary memory
# on every other host and a guest must not probe them.
bash src/c4bb/tests/check-fork-arena.sh || fail=1
ww_off=$(timeout 300 $C4BB -c 40000000 $IMAGES/bb_whowrote.c4r 2>/dev/null)
ww_on=$(timeout 300 $C4BB --whowrote -c 40000000 $IMAGES/bb_whowrote.c4r 2>/dev/null)
if echo "$ww_off" | grep -qF "port silent" && \
   echo "$ww_on" | grep -qF "two stores, two different PCs, OK"; then
    echo "test-c4bb: whowrote port silent when absent, exact when fitted OK"
else
    echo "test-c4bb: whowrote port FAILED"; fail=1
    echo "  without: $ww_off"; echo "  with:    $ww_on"
fi

# Two commands in one session, then quit. Nothing in this suite ran
# more than one command per boot, which is why F18 - the line
# discipline handing a reader several lines at once, so every line
# after the first was thrown away - survived so long: the shell
# answered the first command and then sat there, looking exactly like
# a hang. The pin is that BOTH run and the session shuts down of its
# own accord rather than being cut off at the cycle budget.
c4ke_multi_out=$(printf 'ls\necho second-command\n\\q\n' | timeout 300 $C4BB -c 60000000 -d $IMAGES/disk $IMAGES/c4ke32.c4r 2>/dev/null)
if echo "$c4ke_multi_out" | grep -qF "entries in /" && \
   echo "$c4ke_multi_out" | grep -qF "second-command" && \
   echo "$c4ke_multi_out" | grep -qF "clean shutdown"; then
    echo "test-c4bb: c4ke two commands in one session OK"
else
    echo "test-c4bb: c4ke two commands in one session FAILED"; fail=1
    echo "$c4ke_multi_out" | tail -8
fi

c4ke_cat_out=$(printf 'cat /usr/src/bin/vfsload.c\n\\q\n' | timeout 300 $C4BB -c 30000000 -d $IMAGES/disk $IMAGES/c4ke32.c4r 2>/dev/null)
if echo "$c4ke_cat_out" | grep -qF "C4KE boot-time filesystem loader"; then
    echo "test-c4bb: c4ke-vfs cat real content OK"
else
    echo "test-c4bb: c4ke-vfs cat real content FAILED"; fail=1
fi

# C4IX boots: shell, protected mode, a spawned user ps task. Budget
# is generous because init.c now also runs vfsload before the shell.
c4ix_out=$(printf 'c4ix-ps.c4r\nexit\n' | timeout 300 $C4BB -c 120000000 -d $IMAGES/disk $IMAGES/c4ix32.c4r 2>/dev/null)
for want in "C4IX booting" "protected mode on for user tasks, preemption on" \
            "c4ix-sh" "c4ix-ps.c4r" "tasks," ; do
    if echo "$c4ix_out" | grep -q "$want"; then
        echo "test-c4bb: c4ix-boot '$want' OK"
    else
        echo "test-c4bb: c4ix-boot '$want' FAILED"; fail=1
    fi
done

# the C4IX VFS: vfsload populates a real hierarchical tree from
# c4ix.vfs.txt at boot (src/c4ix/user/vfsload.c). KNOWN ISSUE: a
# timing-sensitive race (documented at length in vfsload.c, not yet
# root-caused - see docs/c4bb-design.md) intermittently corrupts one
# entry's value, so this only requires the run to complete and load
# MOST entries, not all of them.
if echo "$c4ix_out" | grep -qE '[4-9][0-9]/[4-9][0-9] entries loaded from c4ix\.vfs\.txt'; then
    echo "test-c4bb: c4ix-vfs manifest mostly loaded OK"
else
    echo "test-c4bb: c4ix-vfs manifest mostly loaded FAILED"
    echo "$c4ix_out" | grep -E 'entries loaded|cannot open' | head -5
    fail=1
fi

# ---- the mailbox ------------------------------------------------------
# Announced, never probed: without the region the probe must say so on
# BOTH hosts (native c4m has no device window, so the same bytes must
# run there untouched). With it, a node harness lays the rings out,
# feeds frames, and pins the echoes, the doorbell and the interrupt.
check bb_mbox $IMAGES/bb_mbox.c4r
node src/c4bb/tests/test-mbox.mjs || fail=1

# ---- the mailbox under C4KE ---------------------------------------------
# A task bound to the host (mbecho) echoes frames through OP_MBOX_*, idling
# in the kernel between them; two tasks (mbpair) message each other.
# Then the same on a PIT ten times slower than the board assumes, the same
# every run: ticks fall due inside C4KE's handlers, which the board must hold
# until the handler's TLEV (machine.js irqHold).
node src/c4bb/tests/test-c4ke-mbox.mjs || fail=1
node src/c4bb/tests/test-c4ke-mbox.mjs --slow-clock || fail=1

# ---- the programmable interrupt timer -------------------------------
# The cycle interrupt fires every N instructions, which is a different
# amount of time on every host; the PIT fires every N milliseconds. This
# checks that it fires at all, that the count is right, and that the
# ticks are spread over real time rather than arriving together.
# The second pass is the one that matters to a kernel: it masks and
# unmasks the timer on every pass of its wait loop, thousands of times
# per period, the way C4KE does around every critical path. A mask that
# restarted the countdown would deliver no ticks at all. The third: a
# tick that falls due inside a handler -- masked, overrun, re-armed --
# waits for its TLEV (machine.js irqHold).
pit_out=$(timeout 120 $C4BB -m 8 $IMAGES/bb_pit.c4r 2>&1)
pit_ok=$(echo "$pit_out" | grep -c "real time")
if [ "$pit_ok" = 2 ] && echo "$pit_out" | grep -q "pit: held"; then
    echo "test-c4bb: pit OK (free running, masked every pass, held in a handler)"
else
    echo "test-c4bb: pit FAILED"; echo "$pit_out" | tail -4; fail=1
fi

# ---- the fused opcodes (79-88) --------------------------------------
# The board executes all ten. This is the differential c4th's assembler
# was written for: each fused opcode hand-assembled into a tiny
# function, its unfused twin into another, both called, answers
# compared. On the host it runs under c4mp because c4m has only three.
# "0 missed traps" is half the point -- before the microcode existed,
# this program took 25 million of them.
fused_out=$($C4BB -s -m 96 -d $IMAGES/fused $IMAGES/fused/c4th32.c4r \
                  core.f asm.f fused.f 2>&1)
if echo "$fused_out" | grep -q "fused: 0 mismatches" &&
   [ "$(echo "$fused_out" | grep -c ' ok$')" = "10" ] &&
   echo "$fused_out" | grep -q "0 missed traps"; then
    echo "test-c4bb: fused all ten OK"
else
    echo "test-c4bb: fused FAILED"
    echo "$fused_out" | tail -5
    fail=1
fi

# A fused image against its unfused twin: same answers, fewer
# instructions. Both numbers matter -- equal output alone would pass if
# the fuse pass had done nothing.
plain_out=$($C4BB -s $IMAGES/factorial.c4r 2>&1)
fuse_out=$($C4BB -s $IMAGES/factorial-fused.c4r 2>&1)
plain_n=$(echo "$plain_out" | sed -n 's/^c4bb: \([0-9]*\) cycles.*/\1/p')
fuse_n=$(echo "$fuse_out" | sed -n 's/^c4bb: \([0-9]*\) cycles.*/\1/p')
if [ "$(echo "$plain_out" | grep -v '^c4bb:')" = "$(echo "$fuse_out" | grep -v '^c4bb:')" ] &&
   [ -n "$fuse_n" ] && [ "$fuse_n" -lt "$plain_n" ]; then
    echo "test-c4bb: fused image OK (same answers, $plain_n -> $fuse_n instructions)"
else
    echo "test-c4bb: fused image FAILED ($plain_n vs $fuse_n)"; fail=1
fi

# step engine vs turbo engine: register-level lockstep
for t in hello32 tests factorial factorial-fused; do
    if node src/c4bb/tools/lockstep.js $IMAGES/$t.c4r >/dev/null 2>&1; then
        echo "test-c4bb: lockstep-$t OK"
    else
        echo "test-c4bb: lockstep-$t FAILED"; fail=1
    fi
done

# Exit status must propagate too
$C4BB $IMAGES/hello32.c4r >/dev/null 2>&1
s1=$?
$C4M32 $IMAGES/hello32.c4r >/dev/null 2>&1
s2=$?
if [ "$s1" = "$s2" ]; then echo "test-c4bb: exit-status OK"; else echo "test-c4bb: exit-status FAILED ($s1 vs $s2)"; fail=1; fi

# ---- C4DOS on the shipped disk --------------------------------------
# The third system in the images set, and the one an embedder gets for
# free: c4dos32.c4r boots the SAME disk as c4ke32 and c4ix32. This pins
# that the image is built, that CONFIG.SYS reaches it (the clock is
# gated behind DEVICE=CLOCK.SYS), that a transient loads and draws, and
# that control comes back to the prompt afterwards.
if [ -f $IMAGES/c4dos32.c4r ]; then
    dos_out=$(printf 'VER\nTIME\nRUN raycast.c4r 15x15 -s 3 -d -n 2 -g 40x12\nECHO dos-ok\nEXIT\n' \
        | timeout 300 $C4BB -c 900000000 -d $IMAGES/disk $IMAGES/c4dos32.c4r 2>/dev/null)
    dos_rows=$(echo "$dos_out" | grep -c '48;5;')
    if echo "$dos_out" | grep -q "clock device installed" \
       && [ "$dos_rows" = 24 ] \
       && echo "$dos_out" | grep -q "dos-ok" \
       && echo "$dos_out" | grep -q "system halted"; then
        echo "test-c4bb: c4dos boots the shared disk OK"
    else
        echo "test-c4bb: c4dos boots the shared disk FAILED (rows=$dos_rows)"
        fail=1
    fi
else
    echo "test-c4bb: c4dos32 image missing, SKIPPED"
fi

if [ $fail = 0 ]; then echo "test-c4bb: OK"; else echo "test-c4bb: FAILURES"; exit 1; fi
